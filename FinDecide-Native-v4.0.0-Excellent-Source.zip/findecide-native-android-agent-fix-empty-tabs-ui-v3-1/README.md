# FinDecide Native 3.0

FinDecide rebuilt as a true Android application using the Android framework. There is no WebView, HTML, JavaScript, Capacitor, PWA shell, remote API, advertising SDK, analytics SDK, or account system.

## Native capabilities

- Forty native financial calculators and decision systems
- Native Android back and predictive-back handling
- No sliders: deliberate number fields prevent accidental changes while scrolling
- Android vibrator-service haptics with an in-app test
- Native notification calendar and launcher shortcuts
- Screenshot shield and device-credential auto-lock
- Native CSV file picker and on-device statement scan
- Native JSON backup/restore
- Native Android share sheet and PDF generation
- Light/dark appearance and edge-inset handling
- Offline-only calculations and local Android storage

## Build

Open **Actions → Build FinDecide Native APK → Run workflow**. When the run succeeds, download the `FinDecide-Native-v3.0.0` artifact.

### Codemagic phone-only fallback

The repository also includes `codemagic.yaml`. In Codemagic, add this GitHub repository, select the `main` branch, choose **FinDecide Native Android APK**, and tap **Start new build**. Download `FinDecide-Native-v3.0.0.apk` from the completed build's artifacts.

This workflow uses the included stable **development-only** key so later native test APKs install as updates to one another. Keep the repository private. The development key must never be used for Google Play; Play submission requires a separate permanent release/upload key and an Android App Bundle (`.aab`).
