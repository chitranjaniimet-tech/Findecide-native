# FinDecide 4.0.0 — Rebuild Notes

## What was rebuilt

- Replaced the fragile two-column weighted `GridLayout` used by category tabs with a guaranteed-width vertical native list. This directly addresses tabs appearing blank on some Android devices.
- Redesigned the home screen as a financial decision dashboard rather than a generic calculator directory.
- Added four clear decision routes: Borrow, Grow, Plan, and Private Utilities.
- Rebuilt tool cards with stronger hierarchy, category/action labels, larger touch targets, and consistent spacing.
- Reworked the top app bar and bottom navigation for cleaner Android-native presentation.
- Preserved all calculators, local data, privacy controls, PDF export, CSV import, reminders, haptics, dark mode, and device-lock functionality.
- Increased app version to 4.0.0 / version code 6.

## Validation status

- Source structure and Java syntax were statically checked.
- Full Gradle compilation could not be run in the isolated editing environment because external Gradle downloads were unavailable.
- The included GitHub Actions and Codemagic configurations remain available for the final Android SDK build.
