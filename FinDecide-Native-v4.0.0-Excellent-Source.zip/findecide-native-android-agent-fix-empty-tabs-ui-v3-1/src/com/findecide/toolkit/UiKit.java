package com.findecide.toolkit;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

final class UiKit {
    static final int INDIGO = Color.rgb(79, 70, 229);
    static final int TEAL = Color.rgb(15, 157, 138);
    static final int AMBER = Color.rgb(224, 135, 28);
    static final int RED = Color.rgb(214, 69, 69);
    static final int GREEN = Color.rgb(7, 133, 104);

    static int dp(Context context, float value) { return Math.round(value * context.getResources().getDisplayMetrics().density); }

    static int ink(Context context) { return AppStore.isDark(context) ? Color.rgb(232, 238, 247) : Color.rgb(16, 42, 67); }
    static int muted(Context context) { return AppStore.isDark(context) ? Color.rgb(153, 170, 192) : Color.rgb(98, 125, 152); }
    static int surface(Context context) { return AppStore.isDark(context) ? Color.rgb(17, 27, 45) : Color.WHITE; }
    static int paper(Context context) { return AppStore.isDark(context) ? Color.rgb(11, 18, 32) : Color.rgb(245, 247, 251); }
    static int line(Context context) { return AppStore.isDark(context) ? Color.rgb(41, 57, 80) : Color.rgb(218, 227, 237); }
    static int soft(Context context) { return AppStore.isDark(context) ? Color.rgb(23, 42, 74) : Color.rgb(238, 242, 255); }

    static GradientDrawable background(int color, float radiusDp, Context context) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(context, radiusDp));
        return drawable;
    }

    static GradientDrawable outlined(int color, int stroke, float radiusDp, Context context) {
        GradientDrawable drawable = background(color, radiusDp, context);
        drawable.setStroke(dp(context, 1), stroke);
        return drawable;
    }

    static TextView text(Context context, String value, float sizeSp, int color, boolean bold) {
        TextView view = new TextView(context);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        view.setLineSpacing(dp(context, 2), 1f);
        view.setIncludeFontPadding(false);
        return view;
    }

    static TextView label(Context context, String value) {
        TextView view = text(context, value.toUpperCase(Locale.getDefault()), 11, muted(context), true);
        view.setLetterSpacing(.06f);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(context, 16);
        params.bottomMargin = dp(context, 6);
        view.setLayoutParams(params);
        return view;
    }

    static EditText input(Context context, String hint, String initial, boolean numeric) {
        EditText input = new EditText(context);
        input.setHint(hint);
        input.setText(initial == null ? "" : initial);
        input.setTextSize(16);
        input.setTextColor(ink(context));
        input.setHintTextColor(muted(context));
        input.setSingleLine(true);
        input.setPadding(dp(context, 14), 0, dp(context, 14), 0);
        input.setMinHeight(dp(context, 52));
        input.setBackground(outlined(surface(context), line(context), 14, context));
        input.setInputType(numeric ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setSelectAllOnFocus(false);
        return input;
    }

    static LinearLayout card(Context context) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(context, 18), dp(context, 18), dp(context, 18), dp(context, 18));
        card.setBackground(outlined(surface(context), line(context), 22, context));
        card.setElevation(dp(context, AppStore.isDark(context) ? 0 : 3));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(context, 14);
        card.setLayoutParams(params);
        return card;
    }

    static TextView button(Context context, String title, boolean primary) {
        TextView button = text(context, title, 14, primary ? Color.WHITE : INDIGO, true);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(context, 50));
        button.setPadding(dp(context, 15), dp(context, 10), dp(context, 15), dp(context, 10));
        button.setBackground(primary ? background(INDIGO, 15, context) : outlined(surface(context), INDIGO, 15, context));
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    static ScrollView page(Context context, LinearLayout content) {
        ScrollView scroll = new ScrollView(context);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setSmoothScrollingEnabled(true);
        scroll.setVerticalScrollBarEnabled(false);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(context, 14), dp(context, 14), dp(context, 14), dp(context, 28));
        scroll.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    static LinearLayout row(Context context) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    static void addWeighted(LinearLayout row, View view, float weight, int leftMargin) {
        Context context = row.getContext();
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        params.leftMargin = dp(context, leftMargin);
        row.addView(view, params);
    }

    static View spacer(Context context, int height) {
        View spacer = new View(context);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(1, dp(context, height)));
        return spacer;
    }

    private UiKit() {}
}
