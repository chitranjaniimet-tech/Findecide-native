package com.findecide.toolkit;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class CalculatorEngine {
    private static final NumberFormat INR = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
    static { INR.setMaximumFractionDigits(0); INR.setMinimumFractionDigits(0); }

    static final class InputSpec {
        final String key, label, hint, initial;
        InputSpec(String key, String label, String hint, String initial) {
            this.key = key; this.label = label; this.hint = hint; this.initial = initial;
        }
    }

    static final class Metric {
        final String label, value;
        Metric(String label, String value) { this.label = label; this.value = value; }
    }

    static final class CalcResult {
        final String primaryLabel, primaryValue, verdict;
        final List<Metric> metrics;
        final boolean warning;
        CalcResult(String primaryLabel, String primaryValue, String verdict, boolean warning, Metric... metrics) {
            this.primaryLabel = primaryLabel; this.primaryValue = primaryValue; this.verdict = verdict;
            this.warning = warning; this.metrics = Arrays.asList(metrics);
        }
        String summary(String tool) {
            StringBuilder out = new StringBuilder("FINDECIDE — ").append(tool.toUpperCase(Locale.US)).append('\n');
            out.append(primaryLabel).append(": ").append(primaryValue).append('\n');
            for (Metric metric : metrics) out.append(metric.label).append(": ").append(metric.value).append('\n');
            out.append("\n").append(verdict).append("\n\nIndicative decision support; verify important assumptions and current rules.");
            return out.toString();
        }
    }

    static View build(MainActivity host, ToolCatalog.Tool tool) {
        switch (tool.id) {
            case "docs": return buildChecklist(host, tool);
            case "saved": return buildSaved(host, tool);
            case "vault": return buildVault(host, tool);
            case "cashflow": return buildCashflow(host, tool);
            case "journal": return buildJournal(host, tool);
            case "decisionmatrix": return buildMatrix(host, tool);
            case "scamshield": return buildScamShield(host, tool);
            case "calendar": return buildCalendar(host, tool);
            default: return buildStandard(host, tool);
        }
    }

    private static View buildStandard(final MainActivity host, final ToolCatalog.Tool tool) {
        final LinearLayout page = new LinearLayout(host);
        LinearLayout intro = UiKit.card(host);
        TextView chip = UiKit.text(host, "● " + tool.kind.toUpperCase(Locale.US), 10, UiKit.TEAL, true);
        chip.setLetterSpacing(.06f);
        intro.addView(chip);
        TextView title = UiKit.text(host, tool.title, 24, UiKit.ink(host), true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleParams.topMargin = UiKit.dp(host, 10);
        title.setLayoutParams(titleParams);
        intro.addView(title);
        TextView description = UiKit.text(host, tool.description + ".", 13, UiKit.muted(host), false);
        LinearLayout.LayoutParams descriptionParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        descriptionParams.topMargin = UiKit.dp(host, 7);
        description.setLayoutParams(descriptionParams);
        intro.addView(description);
        page.addView(intro);

        final Map<String, EditText> fields = new HashMap<>();
        LinearLayout inputCard = UiKit.card(host);
        for (InputSpec spec : inputs(tool.id)) {
            inputCard.addView(UiKit.label(host, spec.label));
            EditText input = UiKit.input(host, spec.hint, spec.initial, true);
            fields.put(spec.key, input);
            inputCard.addView(input);
        }
        final TextView error = UiKit.text(host, "", 12, UiKit.RED, true);
        LinearLayout.LayoutParams errorParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        errorParams.topMargin = UiKit.dp(host, 10);
        error.setLayoutParams(errorParams);
        inputCard.addView(error);
        TextView calculate = UiKit.button(host, actionLabel(tool.id), true);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        buttonParams.topMargin = UiKit.dp(host, 8);
        calculate.setLayoutParams(buttonParams);
        inputCard.addView(calculate);
        page.addView(inputCard);

        final LinearLayout resultHost = new LinearLayout(host);
        resultHost.setOrientation(LinearLayout.VERTICAL);
        page.addView(resultHost);
        host.bindClick(calculate, new View.OnClickListener() {
            @Override public void onClick(View view) {
                hideKeyboard(host, view);
                error.setText("");
                try {
                    Map<String, Double> values = new HashMap<>();
                    for (Map.Entry<String, EditText> entry : fields.entrySet()) values.put(entry.getKey(), number(entry.getValue().getText().toString()));
                    CalcResult result = calculate(tool.id, values);
                    resultHost.removeAllViews();
                    resultHost.addView(resultCard(host, tool, result));
                    host.haptic(true);
                } catch (IllegalArgumentException problem) {
                    error.setText(problem.getMessage());
                    host.haptic(false);
                } catch (Exception problem) {
                    error.setText("Please check the entered values and try again.");
                }
            }
        });
        return UiKit.page(host, page);
    }

    private static LinearLayout resultCard(final MainActivity host, final ToolCatalog.Tool tool, final CalcResult result) {
        LinearLayout card = UiKit.card(host);
        card.setContentDescription("Calculation result");
        card.addView(UiKit.text(host, result.primaryLabel.toUpperCase(Locale.US), 10, UiKit.muted(host), true));
        TextView primary = UiKit.text(host, result.primaryValue, 31, result.warning ? UiKit.AMBER : UiKit.INDIGO, true);
        LinearLayout.LayoutParams primaryParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        primaryParams.topMargin = UiKit.dp(host, 5);
        primaryParams.bottomMargin = UiKit.dp(host, 12);
        primary.setLayoutParams(primaryParams);
        card.addView(primary);
        for (Metric metric : result.metrics) {
            LinearLayout row = UiKit.row(host);
            row.setPadding(0, UiKit.dp(host, 10), 0, UiKit.dp(host, 10));
            TextView key = UiKit.text(host, metric.label, 12, UiKit.muted(host), false);
            TextView value = UiKit.text(host, metric.value, 13, UiKit.ink(host), true);
            value.setGravity(Gravity.END);
            UiKit.addWeighted(row, key, 1f, 0);
            UiKit.addWeighted(row, value, 1f, 8);
            card.addView(row);
        }
        TextView verdict = UiKit.text(host, result.verdict, 13, UiKit.ink(host), false);
        verdict.setPadding(UiKit.dp(host, 13), UiKit.dp(host, 13), UiKit.dp(host, 13), UiKit.dp(host, 13));
        verdict.setBackground(UiKit.outlined(result.warning ? (AppStore.isDark(host) ? Color.rgb(57,44,18) : Color.rgb(255,247,224)) : (AppStore.isDark(host) ? Color.rgb(13,51,44) : Color.rgb(232,249,243)), result.warning ? UiKit.AMBER : UiKit.GREEN, 14, host));
        LinearLayout.LayoutParams verdictParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        verdictParams.topMargin = UiKit.dp(host, 8);
        verdict.setLayoutParams(verdictParams);
        card.addView(verdict);

        LinearLayout actions = UiKit.row(host);
        TextView share = UiKit.button(host, "Share", false);
        TextView pdf = UiKit.button(host, "Save PDF", false);
        UiKit.addWeighted(actions, share, 1f, 0);
        UiKit.addWeighted(actions, pdf, 1f, 8);
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        actionParams.topMargin = UiKit.dp(host, 14);
        actions.setLayoutParams(actionParams);
        card.addView(actions);
        final String summary = result.summary(tool.title);
        host.bindClick(share, new View.OnClickListener() { @Override public void onClick(View v) { host.shareText(tool.title, summary); } });
        host.bindClick(pdf, new View.OnClickListener() { @Override public void onClick(View v) { host.requestPdf(tool.title, summary); } });
        if ("emi".equals(tool.id)) {
            TextView save = UiKit.button(host, "Save loan profile", true);
            LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            saveParams.topMargin = UiKit.dp(host, 9);
            save.setLayoutParams(saveParams);
            card.addView(save);
            host.bindClick(save, new View.OnClickListener() { @Override public void onClick(View v) { saveLoanResult(host, result); } });
        }
        return card;
    }

    private static String actionLabel(String id) {
        if ("twin".equals(id)) return "Run both futures";
        if ("moneyhealth".equals(id) || "health".equals(id)) return "Build diagnostic";
        if ("debtplan".equals(id)) return "Compare payoff strategies";
        if ("compare".equals(id)) return "Rank the offers";
        if ("bonusplan".equals(id)) return "Build priority waterfall";
        return "Calculate securely";
    }

    private static List<InputSpec> inputs(String id) {
        switch (id) {
            case "emi": return list(i("amount","Loan amount","e.g. 4000000","4000000"),i("rate","Annual interest rate (%)","e.g. 8.4","8.4"),i("years","Tenure (years)","e.g. 20","20"));
            case "eligibility": return list(i("income","Net monthly income","₹ per month","100000"),i("existing","Existing monthly EMIs","₹ per month","10000"),i("foir","Maximum FOIR (%)","e.g. 55","55"),i("rate","Interest rate (%)","e.g. 8.4","8.4"),i("years","Tenure (years)","e.g. 20","20"));
            case "health": return list(i("income","Net monthly income","₹ per month","150000"),i("existing","Existing EMIs","₹ per month","10000"),i("loan","Requested loan","₹","5000000"),i("property","Property value","₹","7000000"),i("rate","Interest rate (%)","%","8.4"),i("years","Tenure (years)","years","20"),i("credit","Credit score","300–900","800"),i("savings","Liquid savings","₹","500000"),i("expense","Essential monthly expense","₹","60000"));
            case "odloan": return list(i("loan","Loan amount","₹","5000000"),i("rate","Regular rate (%)","%","8.4"),i("years","Tenure (years)","years","20"),i("parked","Opening surplus parked","₹","500000"),i("monthly","Monthly surplus added","₹","10000"),i("premium","OD rate premium (%)","%","0.25"),i("fee","Extra OD fees","₹","0"));
            case "aprplus": return list(i("loan","Sanctioned loan","₹","1000000"),i("rate","Headline rate (%)","%","10"),i("years","Tenure (years)","years","5"),i("fee","Processing fee (%)","%","1"),i("gst","GST on fee (%)","%","18"),i("insurance","Upfront insurance / charges","₹","15000"));
            case "reset": return list(i("balance","Outstanding balance","₹","4000000"),i("oldRate","Current rate (%)","%","8.4"),i("newRate","New rate (%)","%","9.4"),i("months","Remaining months","months","240"));
            case "debtplan": return list(i("cardBal","Card balance","₹","100000"),i("cardRate","Card rate (%)","%","36"),i("cardMin","Card minimum payment","₹","5000"),i("loanBal","Personal-loan balance","₹","300000"),i("loanRate","Personal-loan rate (%)","%","14"),i("loanMin","Personal-loan EMI","₹","8000"),i("otherBal","Other debt balance","₹","450000"),i("otherRate","Other debt rate (%)","%","9"),i("otherMin","Other debt EMI","₹","9000"),i("extra","Extra monthly payment","₹","5000"));
            case "rentbuy": return list(i("price","Property price","₹","8000000"),i("down","Down payment","₹","2000000"),i("rate","Loan rate (%)","%","8.4"),i("years","Loan tenure (years)","years","20"),i("rent","Current monthly rent","₹","30000"),i("rentGrowth","Annual rent growth (%)","%","6"),i("propertyGrowth","Property growth (%)","%","6"),i("return","Investment return (%)","%","10"),i("horizon","Comparison horizon (years)","years","10"));
            case "prepayinvest": return list(i("balance","Loan balance","₹","4000000"),i("rate","Loan rate (%)","%","8.4"),i("months","Remaining months","months","180"),i("amount","One-time amount","₹","500000"),i("return","Expected investment return (%)","%","10"),i("tax","Tax on investment gain (%)","%","12.5"));
            case "moratorium": return list(i("balance","Loan balance","₹","1000000"),i("rate","Annual rate (%)","%","10"),i("months","Remaining months","months","60"),i("holiday","Moratorium months","months","6"));
            case "creditescape": return list(i("balance","Card balance","₹","200000"),i("rate","Annual card rate (%)","%","36"),i("minPct","Minimum due (%)","%","5"),i("floor","Minimum due floor","₹","500"),i("payment","Planned fixed payment","₹","15000"),i("target","Target payoff months","months","18"));
            case "compare": return list(i("loan","Loan amount","₹","3000000"),i("years","Tenure (years)","years","10"),i("rateA","Offer A rate (%)","%","8.4"),i("feeA","Offer A fees","₹","15000"),i("rateB","Offer B rate (%)","%","8.6"),i("feeB","Offer B fees","₹","5000"),i("rateC","Offer C rate (%)","%","8.2"),i("feeC","Offer C fees","₹","30000"));
            case "flat": return list(i("amount","Loan amount","₹","500000"),i("flatRate","Quoted flat rate (%)","%","8"),i("years","Tenure (years)","years","5"),i("fee","Upfront fees","₹","5000"));
            case "bt": return list(i("balance","Current balance","₹","3000000"),i("oldRate","Current rate (%)","%","9.2"),i("newRate","New lender rate (%)","%","8.4"),i("months","Remaining months","months","180"),i("fee","Switching costs","₹","30000"));
            case "propertycost": return list(i("price","Purchase price","₹","8000000"),i("loan","Proposed loan","₹","6000000"),i("stamp","Stamp duty (%)","%","6"),i("registration","Registration / legal cost","₹","100000"),i("interiors","Interiors and moving","₹","300000"),i("reserve","Reserve after purchase","₹","500000"),i("savings","Available savings","₹","3000000"));
            case "wealth": return list(i("monthly","Monthly SIP","₹","25000"),i("step","Annual SIP step-up (%)","%","10"),i("lump","Existing / lump sum","₹","500000"),i("return","Expected annual return (%)","%","10"),i("years","Investment years","years","15"));
            case "deposits": return list(i("principal","FD principal","₹","500000"),i("monthly","Monthly recurring deposit","₹","10000"),i("rate","Annual interest rate (%)","%","7"),i("years","Term (years)","years","5"),i("compound","Compounding per year","1, 2 or 4","4"));
            case "swp": return list(i("corpus","Starting corpus","₹","5000000"),i("return","Expected annual return (%)","%","8"),i("withdrawal","First monthly withdrawal","₹","40000"),i("inflation","Annual withdrawal increase (%)","%","6"));
            case "realreturn": return list(i("amount","Starting amount","₹","500000"),i("return","Annual return (%)","%","10"),i("tax","Tax on gain (%)","%","12.5"),i("inflation","Inflation (%)","%","6"),i("years","Holding period (years)","years","10"));
            case "rebalance": return list(i("equity","Current equity","₹","700000"),i("debt","Current debt assets","₹","200000"),i("gold","Current gold","₹","50000"),i("cash","Current cash","₹","50000"),i("eqTarget","Equity target (%)","%","60"),i("debtTarget","Debt target (%)","%","25"),i("goldTarget","Gold target (%)","%","10"),i("cashTarget","Cash target (%)","%","5"),i("fresh","Fresh investment","₹","100000"));
            case "tax": return list(i("income","Gross annual income","₹","1500000"),i("standard","Eligible standard deduction","₹","75000"),i("oldDeductions","Old-regime deductions/exemptions","₹","250000"));
            case "hra": return list(i("basic","Annual basic salary","₹","600000"),i("da","Annual DA forming retirement benefits","₹","0"),i("hra","Annual HRA received","₹","240000"),i("rent","Annual rent paid","₹","300000"),i("metro","Metro city? Enter 1 for yes, 0 for no","1 or 0","1"));
            case "emergency": return list(i("expense","Essential monthly spending","₹","40000"),i("emi","Monthly EMIs","₹","20000"),i("dependants","Number of dependants","count","3"),i("incomeRisk","Income uncertainty: 1 low, 2 medium, 3 high","1–3","2"),i("current","Current emergency reserve","₹","120000"),i("monthlySave","Monthly amount available","₹","10000"));
            case "retire": return list(i("age","Current age","years","40"),i("retire","Retirement age","years","60"),i("life","Planning age","years","85"),i("expense","Current monthly expense","₹","60000"),i("inflation","Inflation (%)","%","6"),i("return","Post-retirement return (%)","%","8"),i("preReturn","Pre-retirement return (%)","%","10"),i("existing","Existing retirement assets","₹","1000000"));
            case "insurance": return list(i("expense","Monthly family expense","₹","60000"),i("years","Support years","years","20"),i("loans","Outstanding loans","₹","4000000"),i("goals","Future goals","₹","3000000"),i("cover","Existing life cover","₹","5000000"),i("assets","Earmarked financial assets","₹","1000000"),i("return","Conservative return (%)","%","7"),i("inflation","Inflation (%)","%","6"));
            case "networth": return list(i("property","Property / real estate","₹","8000000"),i("investments","Investments","₹","2000000"),i("bank","Bank and cash","₹","500000"),i("otherAssets","Other assets","₹","500000"),i("homeLoan","Home-loan balance","₹","4000000"),i("otherLoans","Other loans / cards","₹","500000"),i("otherLiabilities","Other liabilities","₹","0"));
            case "moneyhealth": return list(i("income","Monthly take-home income","₹","150000"),i("expense","Essential monthly spending","₹","60000"),i("emi","Monthly EMIs","₹","20000"),i("liquid","Liquid savings","₹","600000"),i("cover","Life cover","₹","15000000"),i("invest","Monthly investing","₹","25000"),i("dependants","Dependants","count","2"),i("health","Health insurance? 1 yes, 0 no","1 or 0","1"));
            case "twin": return list(i("income","Monthly income","₹","150000"),i("expense","Essential spending","₹","60000"),i("emi","Monthly EMIs","₹","25000"),i("invest","Monthly investing","₹","20000"),i("assets","Current financial assets","₹","1000000"),i("liabilities","Current liabilities","₹","3000000"),i("return","Investment return (%)","%","9"),i("growth","Income growth (%)","%","6"),i("inflation","Expense inflation (%)","%","6"),i("years","Simulation years","years","5"),i("shockPct","Income reduction (%)","%","50"),i("shockMonths","Shock duration (months)","months","6"),i("shockStart","Shock starts after months","months","12"));
            case "bonusplan": return list(i("amount","Amount received","₹","500000"),i("tax","Tax reserve","₹","50000"),i("debt","High-cost debt","₹","100000"),i("emergency","Emergency-fund target","₹","300000"),i("current","Current reserve","₹","200000"),i("goal","Essential near-term goal gap","₹","50000"));
            case "gst": return list(i("amount","Amount","₹","100000"),i("rate","GST rate (%)","%","18"),i("inclusive","Price includes GST? 1 yes, 0 no","1 or 0","0"));
            case "words": return list(i("amount","Rupee amount","₹","1234567"));
            case "dscr": return list(i("income","Annual net operating income","₹","1500000"),i("existing","Existing annual debt service","₹","240000"),i("loan","Proposed new loan","₹","3000000"),i("rate","New loan rate (%)","%","11"),i("years","New loan tenure (years)","years","7"),i("target","Target DSCR","e.g. 1.5","1.5"));
            default: return Collections.emptyList();
        }
    }

    private static InputSpec i(String key, String label, String hint, String initial) { return new InputSpec(key,label,hint,initial); }
    @SafeVarargs private static <T> List<T> list(T... values) { return Arrays.asList(values); }

    private static CalcResult calculate(String id, Map<String, Double> x) {
        switch (id) {
            case "emi": {
                double amount = required(x,"amount"), rate = required(x,"rate"), years = required(x,"years");
                int months = boundedMonths(years * 12); double payment = emi(amount,rate,months), interest = payment*months-amount;
                return r("Monthly EMI",money(payment),"This is the contractual cashflow before optional prepayments. Confirm the lender's reset, fee and rounding rules.",false,m("Total interest",money(interest)),m("Total payable",money(amount+interest)),m("Payment period",months+" months"));
            }
            case "eligibility": {
                double income=required(x,"income"), existing=v(x,"existing"), foir=range(x,"foir",10,90), rate=required(x,"rate"); int months=boundedMonths(required(x,"years")*12);
                double capacity=Math.max(income*foir/100-existing,0), loan=presentValue(capacity,rate,months);
                return r("Estimated loan capacity",money(loan),capacity<=0?"Existing obligations already consume the selected FOIR. Closing debt or documenting stable eligible income should come before a fresh application.":"Treat this as a capacity screen, not a sanction. Lender policy, age, income continuity and credit conduct still apply.",capacity<=0,m("Available EMI",money(capacity)),m("FOIR ceiling",pct(foir)),m("Assumed tenure",months+" months"));
            }
            case "health": {
                double income=required(x,"income"), existing=v(x,"existing"), loan=required(x,"loan"), property=required(x,"property"), rate=required(x,"rate"), credit=v(x,"credit"), savings=v(x,"savings"), expense=v(x,"expense"); int months=boundedMonths(required(x,"years")*12);
                double proposed=emi(loan,rate,months),foir=(existing+proposed)/income*100,ltv=loan/property*100,buffer=savings/Math.max(expense+existing+proposed,1);int score=0;score+=credit>=800?25:credit>=750?20:credit>=700?12:4;score+=foir<=40?25:foir<=50?18:foir<=60?8:0;score+=ltv<=70?20:ltv<=80?15:ltv<=90?7:0;score+=buffer>=6?20:buffer>=3?12:buffer>=1?5:0;score+=income>expense+existing+proposed?10:0;
                String grade=score>=80?"Strong":score>=65?"Workable":score>=45?"Needs attention":"High risk";
                return r("Readiness score",score+" / 100 · "+grade,"The score is a preparation diagnostic—not a credit decision. Improve the lowest of FOIR, LTV, credit conduct or cash buffer first.",score<65,m("Proposed EMI",money(proposed)),m("FOIR",pct(foir)),m("LTV",pct(ltv)),m("Cash buffer",one(buffer)+" months"));
            }
            case "odloan": {
                double loan=required(x,"loan"),rate=required(x,"rate"),years=required(x,"years"),parked=v(x,"parked"),monthly=v(x,"monthly"),premium=v(x,"premium"),fee=v(x,"fee");int months=boundedMonths(years*12);double regularEmi=emi(loan,rate,months),regularInterest=regularEmi*months-loan,odRate=rate+premium,balance=loan,surplus=parked,odInterest=0;int paid=0;
                while(balance>.5&&paid<months){double interest=Math.max(balance-surplus,0)*odRate/1200;odInterest+=interest;balance+=interest;balance-=Math.min(balance,regularEmi);surplus+=monthly;paid++;}
                double saving=regularInterest-odInterest-fee;
                return r("Estimated net benefit",signedMoney(saving),saving>0?"The OD structure is beneficial only while surplus remains parked. Withdrawals, rate premium and product fees can reverse the result.":"Under these assumptions the OD premium and fees outweigh the interest benefit. A regular loan may be simpler.",saving<=0,m("Regular interest",money(regularInterest)),m("OD interest model",money(odInterest)),m("OD rate assumed",pct(odRate)),m("Modelled closure",paid+" months"));
            }
            case "aprplus": {
                double loan=required(x,"loan"),rate=required(x,"rate"),years=required(x,"years"),feePct=v(x,"fee"),gst=v(x,"gst"),insurance=v(x,"insurance");int months=boundedMonths(years*12);double fees=loan*feePct/100*(1+gst/100)+insurance,net=loan-fees;if(net<=0)throw new IllegalArgumentException("Upfront charges cannot consume the entire disbursal.");double payment=emi(loan,rate,months),apr=rateFromPayment(net,payment,months);
                return r("Fee-adjusted annual rate",pct(apr),"APR rises because repayment is calculated on the sanctioned amount while you receive less cash. Compare net disbursal and mandatory charges across lenders.",apr>rate+1,m("Headline rate",pct(rate)),m("Net amount received",money(net)),m("Upfront charges",money(fees)),m("Monthly EMI",money(payment)));
            }
            case "reset": {
                double balance=required(x,"balance"),oldRate=required(x,"oldRate"),newRate=required(x,"newRate");int months=boundedMonths(required(x,"months"));double oldEmi=emi(balance,oldRate,months),newEmi=emi(balance,newRate,months),change=newEmi-oldEmi,newTenure=tenureFromPayment(balance,newRate,oldEmi);
                return r("Revised EMI",money(newEmi),change>0?"If EMI stays unchanged, the modelled tenure becomes "+Math.round(newTenure)+" months. Ask the lender which lever—EMI or tenure—will actually change.":"The lower rate reduces the contractual burden. Confirm the reset date and benchmark spread.",change>0,m("Current EMI",money(oldEmi)),m("Monthly change",signedMoney(change)),m("Tenure at old EMI",Math.round(newTenure)+" months"));
            }
            case "debtplan": {
                List<Debt> debts=Arrays.asList(new Debt(v(x,"cardBal"),v(x,"cardRate"),v(x,"cardMin")),new Debt(v(x,"loanBal"),v(x,"loanRate"),v(x,"loanMin")),new Debt(v(x,"otherBal"),v(x,"otherRate"),v(x,"otherMin")));double extra=v(x,"extra");Payoff avalanche=payoff(debts,extra,true),snowball=payoff(debts,extra,false);if(!avalanche.valid||!snowball.valid)throw new IllegalArgumentException("The entered payments must exceed monthly interest.");
                double saved=snowball.interest-avalanche.interest;
                return r("Avalanche payoff",duration(avalanche.months),"Avalanche targets the highest rate and is mathematically cheaper. Snowball can still be useful when quick account closures improve motivation.",false,m("Avalanche interest",money(avalanche.interest)),m("Snowball payoff",duration(snowball.months)),m("Snowball interest",money(snowball.interest)),m("Interest avoided",money(Math.max(saved,0))));
            }
            case "rentbuy": {
                double price=required(x,"price"),down=v(x,"down"),rate=required(x,"rate"),years=required(x,"years"),rent=required(x,"rent"),rentGrowth=v(x,"rentGrowth"),propertyGrowth=v(x,"propertyGrowth"),ret=v(x,"return"),horizon=range(x,"horizon",1,40);double loan=Math.max(price-down,0);int loanMonths=boundedMonths(years*12),horizonMonths=(int)Math.round(horizon*12);double payment=loan>0?emi(loan,rate,loanMonths):0,balance=loan,invested=down,cumRent=0;
                for(int month=0;month<horizonMonths;month++){if(balance>0){double interest=balance*rate/1200;balance=Math.max(0,balance+interest-payment);}double currentRent=rent*Math.pow(1+rentGrowth/100,Math.floor(month/12));cumRent+=currentRent;invested*=1+ret/1200;double cashDifference=payment-currentRent;if(cashDifference>0)invested+=cashDifference;}
                double homeValue=price*Math.pow(1+propertyGrowth/100,horizon),ownerWealth=homeValue-balance,renterWealth=invested,diff=ownerWealth-renterWealth;
                return r(diff>=0?"Buying leads by":"Renting leads by",money(Math.abs(diff)),"This is most sensitive to property appreciation, investment discipline, maintenance and transaction costs. Stress-test those before deciding.",Math.abs(diff)<price*.05,m("Owner ending equity",money(ownerWealth)),m("Renter investments",money(renterWealth)),m("Rent paid",money(cumRent)),m("Horizon",Math.round(horizon)+" years"));
            }
            case "prepayinvest": {
                double balance=required(x,"balance"),rate=required(x,"rate"),amount=required(x,"amount"),ret=required(x,"return"),tax=v(x,"tax");int months=boundedMonths(required(x,"months"));amount=Math.min(amount,balance);double oldEmi=emi(balance,rate,months),oldInterest=oldEmi*months-balance,newEmi=emi(balance-amount,rate,months),newInterest=newEmi*months-(balance-amount),saved=oldInterest-newInterest;double gross=amount*Math.pow(1+ret/1200,months),investment=amount+(gross-amount)*(1-tax/100),advantage=investment-amount-saved;
                return r(advantage>0?"Investment advantage":"Prepayment advantage",money(Math.abs(advantage)),advantage>0?"The investment wins only if the assumed return arrives after tax. Prepayment provides a certain saving equal to the loan cost.":"The certain interest saving exceeds the assumed after-tax investment gain. Confirm prepayment charges first.",Math.abs(advantage)<amount*.05,m("Interest saved",money(saved)),m("After-tax investment value",money(investment)),m("Investment gain",money(investment-amount)));
            }
            case "moratorium": {
                double balance=required(x,"balance"),rate=required(x,"rate");int months=boundedMonths(required(x,"months")),holiday=(int)range(x,"holiday",1,36);double oldEmi=emi(balance,rate,months),grown=balance*Math.pow(1+rate/1200,holiday),added=grown-balance,newEmi=emi(grown,rate,months),extra=newEmi*months-(oldEmi*months);
                return r("Balance after holiday",money(grown),"A moratorium postpones cashflow; it does not waive interest. Ask whether accrued interest is capitalized or recovered separately.",true,m("Interest added",money(added)),m("Old EMI",money(oldEmi)),m("New EMI",money(newEmi)),m("Extra lifetime cost",money(extra)));
            }
            case "creditescape": {
                double balance=required(x,"balance"),rate=required(x,"rate"),minPct=range(x,"minPct",1,100)/100,floor=v(x,"floor"),payment=v(x,"payment");int target=(int)range(x,"target",1,600);double monthly=rate/1200,needed=monthly==0?balance/target:balance*monthly/(1-Math.pow(1+monthly,-target));CardPlan minimum=cardPlan(balance,rate,minPct,floor,0),fixed=cardPlan(balance,rate,0,0,payment);if(payment>0&&!fixed.valid)throw new IllegalArgumentException("The fixed payment does not reliably cover interest.");
                return r("Payment for target",money(Math.ceil(needed/100)*100),"Paying only the changing minimum can keep high-cost debt alive for years. Stop fresh card spending while executing the payoff plan.",payment<needed,m("Minimum-due payoff",minimum.valid?duration(minimum.months):"Not repaid"),m("Minimum-plan interest",minimum.valid?money(minimum.interest):"Compounds"),m("Your fixed-plan payoff",fixed.valid?duration(fixed.months):"Enter payment"),m("Your plan interest",fixed.valid?money(fixed.interest):"—"));
            }
            case "compare": {
                double loan=required(x,"loan"),years=required(x,"years");int months=boundedMonths(years*12);double a=emi(loan,required(x,"rateA"),months)*months+v(x,"feeA"),b=emi(loan,required(x,"rateB"),months)*months+v(x,"feeB"),c=emi(loan,required(x,"rateC"),months)*months+v(x,"feeC");double best=Math.min(a,Math.min(b,c));String winner=best==a?"Offer A":best==b?"Offer B":"Offer C";
                return r("Lowest complete cost",winner+" · "+money(best),"Cost is only one axis. Compare reset clauses, insurance bundling, service quality and prepayment rules before accepting.",false,m("Offer A total",money(a)),m("Offer B total",money(b)),m("Offer C total",money(c)),m("Gap to costliest",money(Math.max(a,Math.max(b,c))-best)));
            }
            case "flat": {
                double amount=required(x,"amount"),flat=required(x,"flatRate"),years=required(x,"years"),fee=v(x,"fee");int months=boundedMonths(years*12);double interest=amount*flat/100*years,payment=(amount+interest)/months,effective=rateFromPayment(amount-fee,payment,months);
                return r("Equivalent reducing rate",pct(effective),"A flat quote applies interest to the original principal throughout the term. Compare the reducing-balance equivalent, not the headline.",effective>flat*1.5,m("Quoted flat rate",pct(flat)),m("Monthly payment",money(payment)),m("Total interest",money(interest)),m("Total payable",money(amount+interest+fee)));
            }
            case "bt": {
                double balance=required(x,"balance"),oldRate=required(x,"oldRate"),newRate=required(x,"newRate"),fee=v(x,"fee");int months=boundedMonths(required(x,"months"));double oldEmi=emi(balance,oldRate,months),newEmi=emi(balance,newRate,months),saving=(oldEmi-newEmi)*months-fee,breakEven=oldEmi>newEmi?fee/(oldEmi-newEmi):Double.POSITIVE_INFINITY;
                return r("Net switching benefit",signedMoney(saving),saving>0?"The transfer pays only if you keep the loan beyond the break-even point and the quoted spread remains applicable.":"Fees consume the modelled interest benefit. Renegotiating with the existing lender may be cleaner.",saving<=0,m("Current EMI",money(oldEmi)),m("New EMI",money(newEmi)),m("Switching cost",money(fee)),m("Break-even",Double.isFinite(breakEven)?Math.ceil(breakEven)+" months":"Never"));
            }
            case "propertycost": {
                double price=required(x,"price"),loan=v(x,"loan"),stamp=v(x,"stamp"),registration=v(x,"registration"),interiors=v(x,"interiors"),reserve=v(x,"reserve"),savings=v(x,"savings");if(loan>price)throw new IllegalArgumentException("The proposed loan cannot exceed the purchase price in this planner.");double down=price-loan,charges=price*stamp/100+registration,needed=down+charges+interiors+reserve,gap=needed-savings;
                return r("Cash required",money(needed),gap>0?"Available savings fall short. Do not fund statutory costs or the emergency reserve with expensive unsecured debt.":"The plan preserves the stated reserve after paying the down payment and purchase costs.",gap>0,m("Down payment",money(down)),m("Taxes and legal costs",money(charges)),m("Interiors / moving",money(interiors)),m(gap>0?"Funding gap":"Surplus after plan",money(Math.abs(gap))));
            }
            case "wealth": {
                double monthly=required(x,"monthly"),step=v(x,"step"),lump=v(x,"lump"),ret=required(x,"return");int years=(int)range(x,"years",1,60),months=years*12;double corpus=lump;double contribution=monthly,total=lump;for(int month=0;month<months;month++){corpus*=1+ret/1200;corpus+=contribution;total+=contribution;if((month+1)%12==0)contribution*=1+step/100;}double gain=corpus-total;
                return r("Projected corpus",money(corpus),"Returns are not guaranteed. Use a lower-return stress case and align the investment mix with the goal horizon.",false,m("Total contributions",money(total)),m("Modelled gain",money(gain)),m("Final monthly SIP",money(contribution)),m("Horizon",years+" years"));
            }
            case "deposits": {
                double principal=v(x,"principal"),monthly=v(x,"monthly"),rate=required(x,"rate"),years=required(x,"years"),compound=Math.max(1,Math.round(v(x,"compound")));int months=boundedMonths(years*12);double fd=principal*Math.pow(1+rate/100/compound,compound*years),rd=0;for(int m=0;m<months;m++){rd*=1+rate/1200;rd+=monthly;}double total=fd+rd,contributed=principal+monthly*months;
                return r("Combined maturity",money(total),"Actual deposit taxation, compounding dates and premature-closure rules may change the received amount.",false,m("FD maturity",money(fd)),m("RD maturity",money(rd)),m("Total deposited",money(contributed)),m("Interest earned",money(total-contributed)));
            }
            case "swp": {
                double corpus=required(x,"corpus"),ret=v(x,"return"),withdrawal=required(x,"withdrawal"),inflation=v(x,"inflation"),start=corpus,total=0;int month=0;while(corpus>0&&month<1200){corpus*=1+ret/1200;double draw=withdrawal*Math.pow(1+inflation/100,Math.floor(month/12));corpus-=draw;total+=Math.min(draw,Math.max(corpus+draw,0));month++;}
                return r("Estimated runway",month>=1200?"Beyond 100 years":duration(month),"This deterministic runway is highly sensitive to sequence-of-returns risk. Keep near-term withdrawals in safer assets.",month<240,m("Starting corpus",money(start)),m("First withdrawal",money(withdrawal)),m("Total modelled withdrawals",money(total)),m("End balance",money(Math.max(corpus,0))));
            }
            case "realreturn": {
                double amount=required(x,"amount"),ret=required(x,"return"),tax=v(x,"tax"),inflation=v(x,"inflation"),years=required(x,"years");double gross=amount*Math.pow(1+ret/100,years),afterTax=amount+(gross-amount)*(1-tax/100),real=afterTax/Math.pow(1+inflation/100,years),realAnnual=(Math.pow(real/amount,1/years)-1)*100;
                return r("Purchasing-power value",money(real),"The nominal balance can rise while real wealth barely grows. Compare investments using after-tax, inflation-adjusted return.",realAnnual<2,m("Nominal ending value",money(gross)),m("After-tax value",money(afterTax)),m("Real annual return",pct(realAnnual)),m("Purchasing-power gain",money(real-amount)));
            }
            case "rebalance": {
                double equity=v(x,"equity"),debt=v(x,"debt"),gold=v(x,"gold"),cash=v(x,"cash"),fresh=v(x,"fresh"),eqT=v(x,"eqTarget"),debtT=v(x,"debtTarget"),goldT=v(x,"goldTarget"),cashT=v(x,"cashTarget");double targets=eqT+debtT+goldT+cashT;if(Math.abs(targets-100)>.01)throw new IllegalArgumentException("Target percentages must total exactly 100.");double total=equity+debt+gold+cash+fresh;if(total<=0)throw new IllegalArgumentException("Enter at least one current asset value.");double eqAction=total*eqT/100-equity,debtAction=total*debtT/100-debt,goldAction=total*goldT/100-gold,cashAction=total*cashT/100-cash;
                return r("Rebalanced portfolio",money(total),"Use fresh contributions for underweight assets first. Review capital-gains tax and exit loads before selling.",false,m("Equity action",action(eqAction)),m("Debt action",action(debtAction)),m("Gold action",action(goldAction)),m("Cash action",action(cashAction)));
            }
            case "tax": {
                double income=required(x,"income"),standard=Math.min(v(x,"standard"),75000),oldDed=v(x,"oldDeductions");double newTaxable=Math.max(0,income-standard),oldTaxable=Math.max(0,income-Math.min(standard,50000)-oldDed),newTax=taxNew(newTaxable),oldTax=taxOld(oldTaxable),saving=Math.abs(oldTax-newTax);String winner=newTax<=oldTax?"New regime":"Old regime";
                return r("Lower indicative tax",winner+" · "+money(Math.min(oldTax,newTax)),"Indicative salary comparison for Tax Year 2026–27. Special-rate income, surcharge, marginal relief and eligibility conditions require the official tax calculator or a tax professional.",Math.abs(oldTax-newTax)<5000,m("New-regime tax",money(newTax)),m("Old-regime tax",money(oldTax)),m("Estimated difference",money(saving)),m("Old taxable income",money(oldTaxable)));
            }
            case "hra": {
                double basic=required(x,"basic"),da=v(x,"da"),hra=required(x,"hra"),rent=required(x,"rent"),salary=basic+da,percent=v(x,"metro")>=.5?.5:.4;double exempt=Math.max(0,Math.min(hra,Math.min(rent-salary*.1,salary*percent)));
                return r("Estimated HRA exemption",money(exempt),"The least of the statutory limits is used. Employer records, actual occupancy and tax-regime eligibility still matter.",exempt<=0,m("HRA received",money(hra)),m("Rent minus 10% salary",money(Math.max(rent-salary*.1,0))),m((percent==.5?"50%":"40%")+" of salary",money(salary*percent)),m("Taxable HRA",money(Math.max(hra-exempt,0))));
            }
            case "emergency": {
                double expense=required(x,"expense"),emi=v(x,"emi"),dependants=v(x,"dependants"),risk=range(x,"incomeRisk",1,3),current=v(x,"current"),save=v(x,"monthlySave");int targetMonths=(int)Math.min(12,3+Math.ceil(dependants/2)+(risk-1)*2);double target=(expense+emi)*targetMonths,gap=Math.max(target-current,0),months=save>0?Math.ceil(gap/save):Double.POSITIVE_INFINITY;
                return r("Recommended reserve",money(target),"Keep the first layer liquid and separate from long-term investments. Higher income uncertainty and dependants justify a larger runway.",gap>0,m("Target runway",targetMonths+" months"),m("Current reserve",money(current)),m("Reserve gap",money(gap)),m("Time to build",Double.isFinite(months)?Math.round(months)+" months":"Add monthly saving"));
            }
            case "retire": {
                double age=range(x,"age",18,80),retire=range(x,"retire",age+1,90),life=range(x,"life",retire+1,110),expense=required(x,"expense"),inflation=v(x,"inflation"),post=v(x,"return"),pre=v(x,"preReturn"),existing=v(x,"existing");double years=retire-age,retirementExpense=expense*Math.pow(1+inflation/100,years),real=(1+post/100)/(1+inflation/100)-1,retirementYears=life-retire,corpus=Math.abs(real)<.00001?retirementExpense*12*retirementYears:retirementExpense*12*(1-Math.pow(1+real,-retirementYears))/real,existingFuture=existing*Math.pow(1+pre/100,years),gap=Math.max(corpus-existingFuture,0),monthlyRate=pre/1200,months=(int)Math.round(years*12),sip=gap<=0?0:Math.abs(monthlyRate)<.0000001?gap/months:gap*monthlyRate/(Math.pow(1+monthlyRate,months)-1);
                return r("Retirement corpus target",money(corpus),"The estimate assumes stable inflation and returns. Revisit it annually and keep healthcare and longevity margins separate.",gap>0,m("Expense at retirement",money(retirementExpense)+" / month"),m("Existing assets at retirement",money(existingFuture)),m("Projected corpus gap",money(gap)),m("Monthly SIP for gap",money(sip)));
            }
            case "insurance": {
                double expense=required(x,"expense"),years=range(x,"years",1,60),loans=v(x,"loans"),goals=v(x,"goals"),cover=v(x,"cover"),assets=v(x,"assets"),ret=v(x,"return"),infl=v(x,"inflation"),real=(1+ret/100)/(1+infl/100)-1,annual=expense*12,corpus=Math.abs(real)<.00001?annual*years:annual*(1-Math.pow(1+real,-years))/real,need=corpus+loans+goals,gap=Math.max(need-cover-assets,0);
                return r("Additional cover gap",money(gap),gap>0?"The model indicates an uncovered family need. Compare pure protection products, exclusions, claim service and term—not investment promises.":"Existing cover and earmarked assets meet this modelled need. Review nominees, policy term and exclusions.",gap>0,m("Family-income corpus",money(corpus)),m("Loans and goals",money(loans+goals)),m("Total modelled need",money(need)),m("Existing resources",money(cover+assets)));
            }
            case "networth": {
                double assets=v(x,"property")+v(x,"investments")+v(x,"bank")+v(x,"otherAssets"),liabilities=v(x,"homeLoan")+v(x,"otherLoans")+v(x,"otherLiabilities"),net=assets-liabilities,ratio=assets>0?liabilities/assets*100:0;
                return r("Net worth",signedMoney(net),net>=0?"Separate liquid, growth and self-use assets when reviewing progress. A positive net worth can still be illiquid.":"Liabilities exceed recorded assets. Prioritize expensive debt and a liquid buffer before adding market risk.",net<0,m("Total assets",money(assets)),m("Total liabilities",money(liabilities)),m("Liability / asset ratio",pct(ratio)),m("Liquid assets",money(v(x,"investments")+v(x,"bank"))));
            }
            case "moneyhealth": {
                double income=required(x,"income"),expense=required(x,"expense"),emi=v(x,"emi"),liquid=v(x,"liquid"),cover=v(x,"cover"),invest=v(x,"invest"),dependants=v(x,"dependants"),health=v(x,"health"),surplus=income-expense-emi,savingsRate=surplus/income*100,debtRatio=emi/income*100,runway=liquid/Math.max(expense+emi,1),investRate=invest/income*100,coverNeed=income*12*(dependants>0?10:3);double score=Math.max(0,Math.min(25,savingsRate/20*25))+Math.max(0,Math.min(20,(55-debtRatio)/35*20))+Math.max(0,Math.min(25,runway/6*25))+Math.max(0,Math.min(10,cover/Math.max(coverNeed,1)*10))+Math.min(5,health*5)+Math.max(0,Math.min(15,investRate/15*15));int rounded=(int)Math.round(score);String grade=rounded>=80?"Strong foundation":rounded>=65?"On track":rounded>=45?"Needs attention":"Priority rebuild";
                return r("Money health score",rounded+" / 100 · "+grade,rounded>=65?"Your strongest move is to maintain the system and review protection, allocation and goals annually.":"Repair the monthly surplus and emergency reserve first; they improve almost every later decision.",rounded<65,m("Savings rate",pct(savingsRate)),m("Debt ratio",pct(debtRatio)),m("Emergency runway",one(runway)+" months"),m("Investment rate",pct(investRate)));
            }
            case "twin": {
                TwinInput in=new TwinInput(x);TwinPath base=twin(in,false),stress=twin(in,true);double impact=base.net-stress.net;
                return r("Stressed future net worth",money(stress.net),stress.low<0?"The selected shock creates a monthly deficit. Build a liquid reserve and identify which SIP or expense can flex before the event occurs.":"The model absorbs the selected income shock without a monthly deficit, although long-term net worth still falls.",stress.low<0,m("Baseline future",money(base.net)),m("Shock impact",money(impact)),m("Weakest monthly cashflow",signedMoney(stress.low)),m("Simulation horizon",in.years+" years"));
            }
            case "bonusplan": {
                double amount=required(x,"amount"),tax=v(x,"tax"),debt=v(x,"debt"),gap=Math.max(v(x,"emergency")-v(x,"current"),0),goal=v(x,"goal");if(tax>amount)throw new IllegalArgumentException("Tax reserve cannot exceed the amount received.");double left=amount,taxA=Math.min(left,tax);left-=taxA;double debtA=Math.min(left,debt);left-=debtA;double emergencyA=Math.min(left,gap);left-=emergencyA;double goalA=Math.min(left,goal);left-=goalA;double investA=left;
                return r("Long-term amount remaining",money(investA),debtA>=debt&&emergencyA>=gap?"The waterfall protects tax, removes stated high-cost debt and fills the resilience gap before investing.":"The windfall cannot cover every layer. Finish the earliest unmet priority instead of spreading tiny amounts everywhere.",debtA<debt||emergencyA<gap,m("Tax reserve",money(taxA)),m("High-cost debt",money(debtA)),m("Emergency reserve",money(emergencyA)),m("Essential goal",money(goalA)));
            }
            case "gst": {
                double amount=required(x,"amount"),rate=range(x,"rate",0,100);boolean inclusive=v(x,"inclusive")>=.5;double base=inclusive?amount/(1+rate/100):amount,gst=inclusive?amount-base:amount*rate/100,total=inclusive?amount:amount+gst;
                return r(inclusive?"Pre-tax value":"Invoice total",money(inclusive?base:total),"The split assumes one GST rate and does not determine place of supply, input-credit eligibility or classification.",false,m("Taxable value",money(base)),m("GST amount",money(gst)),m("CGST component",money(gst/2)),m("SGST component",money(gst/2)));
            }
            case "words": {
                long amount=Math.round(required(x,"amount"));
                return r("Amount in words","Rupees "+wordsIndian(amount)+" only","Use this wording as a drafting aid and verify the numeric amount before signing a document.",false,m("Indian format",money(amount)),m("Crore value",one(amount/10000000.0)+" crore"));
            }
            case "dscr": {
                double income=required(x,"income"),existing=v(x,"existing"),loan=required(x,"loan"),rate=required(x,"rate"),years=required(x,"years"),target=required(x,"target");double newDebt=emi(loan,rate,boundedMonths(years*12))*12,total=existing+newDebt,dscr=income/Math.max(total,1),capacity=Math.max(income/target-existing,0),maxLoan=presentValue(capacity/12,rate,boundedMonths(years*12));
                return r("Projected DSCR",two(dscr)+"×",dscr>=target?"Modelled operating income covers the target debt service. Validate cash accruals, seasonality and existing obligations from statements.":"The proposed debt falls below the chosen DSCR threshold. Reduce the amount, extend feasible tenure or strengthen sustainable cash accruals.",dscr<target,m("Annual new debt service",money(newDebt)),m("Total annual debt service",money(total)),m("Target DSCR",two(target)+"×"),m("Loan at target",money(maxLoan)));
            }
            default: throw new IllegalArgumentException("This native tool is not configured yet.");
        }
    }

    private static CalcResult r(String label,String primary,String verdict,boolean warning,Metric...metrics){return new CalcResult(label,primary,verdict,warning,metrics);}
    private static Metric m(String label,String value){return new Metric(label,value);}
    private static double v(Map<String,Double>x,String key){Double value=x.get(key);return value==null?0:value;}
    private static double required(Map<String,Double>x,String key){double value=v(x,key);if(value<=0)throw new IllegalArgumentException("Complete every required field with a value greater than zero.");return value;}
    private static double range(Map<String,Double>x,String key,double min,double max){double value=v(x,key);if(value<min||value>max)throw new IllegalArgumentException("Check the entered range for “"+key+"”.");return value;}
    private static int boundedMonths(double months){int value=(int)Math.round(months);if(value<1||value>1200)throw new IllegalArgumentException("Use a period between 1 month and 100 years.");return value;}
    private static double number(String value){try{return Double.parseDouble(value.replace(",","").replace("₹","").trim());}catch(Exception e){return 0;}}
    private static String money(double value){return INR.format(Math.round(Math.max(value,0)));}
    private static String signedMoney(double value){return (value<0?"− ":value>0?"+ ":"")+money(Math.abs(value));}
    private static String pct(double value){return String.format(Locale.US,"%.2f%%",value);}
    private static String one(double value){return String.format(Locale.US,"%.1f",value);}
    private static String two(double value){return String.format(Locale.US,"%.2f",value);}
    private static double emi(double principal,double annual,int months){if(principal<=0)return 0;double rate=annual/1200;if(rate==0)return principal/months;return principal*rate*Math.pow(1+rate,months)/(Math.pow(1+rate,months)-1);}
    private static double presentValue(double payment,double annual,int months){double rate=annual/1200;if(rate==0)return payment*months;return payment*(1-Math.pow(1+rate,-months))/rate;}
    private static double rateFromPayment(double principal,double payment,int months){double lo=0,hi=100;for(int i=0;i<80;i++){double mid=(lo+hi)/2;if(emi(principal,mid,months)>payment)hi=mid;else lo=mid;}return (lo+hi)/2;}
    private static double tenureFromPayment(double principal,double annual,double payment){double rate=annual/1200;if(payment<=principal*rate)return 1200;if(rate==0)return principal/payment;return -Math.log(1-principal*rate/payment)/Math.log(1+rate);}
    private static String duration(int months){if(months>=600)return "50+ years";int years=months/12,rest=months%12;return (years>0?years+"y ":"")+(rest>0?rest+"m":"");}
    private static String action(double amount){return (amount>=0?"Buy ":"Reduce ")+money(Math.abs(amount));}

    private static double taxNew(double taxable){double tax=slab(taxable,new double[]{400000,800000,1200000,1600000,2000000,2400000},new double[]{0,.05,.10,.15,.20,.25,.30});if(taxable<=1200000)tax=0;return tax*1.04;}
    private static double taxOld(double taxable){double tax=slab(taxable,new double[]{250000,500000,1000000},new double[]{0,.05,.20,.30});if(taxable<=500000)tax=0;return tax*1.04;}
    private static double slab(double income,double[] edges,double[] rates){double tax=0,previous=0;for(int i=0;i<rates.length;i++){double top=i<edges.length?edges[i]:Double.POSITIVE_INFINITY;if(income>previous)tax+=Math.max(0,Math.min(income,top)-previous)*rates[i];if(income<=top)break;previous=top;}return tax;}

    private static final class Debt {double balance,rate,min;Debt(double b,double r,double m){balance=b;rate=r;min=m;}Debt copy(){return new Debt(balance,rate,min);}}
    private static final class Payoff {int months;double interest;boolean valid;Payoff(int m,double i,boolean v){months=m;interest=i;valid=v;}}
    private static Payoff payoff(List<Debt> source,double extra,boolean avalanche){List<Debt> debts=new ArrayList<>();for(Debt d:source)if(d.balance>0)debts.add(d.copy());double interest=0;int month=0;while(!debts.isEmpty()&&month<600){double budget=extra;for(Debt d:debts){double charge=d.balance*d.rate/1200;interest+=charge;d.balance+=charge;if(d.min<=charge+.01)return new Payoff(month,interest,false);double pay=Math.min(d.balance,d.min);d.balance-=pay;}debts.removeAll(zeroDebts(debts));if(debts.isEmpty())break;Collections.sort(debts,new Comparator<Debt>(){@Override public int compare(Debt a,Debt b){return avalanche?Double.compare(b.rate,a.rate):Double.compare(a.balance,b.balance);}});Debt target=debts.get(0);double extraPay=Math.min(target.balance,budget);target.balance-=extraPay;debts.removeAll(zeroDebts(debts));month++;}return new Payoff(month,interest,debts.isEmpty());}
    private static List<Debt> zeroDebts(List<Debt> debts){List<Debt> zero=new ArrayList<>();for(Debt d:debts)if(d.balance<.5)zero.add(d);return zero;}
    private static final class CardPlan {int months;double interest;boolean valid;CardPlan(int m,double i,boolean v){months=m;interest=i;valid=v;}}
    private static CardPlan cardPlan(double balance,double annual,double pct,double floor,double fixed){double interest=0;int month=0;while(balance>.5&&month<600){double charge=balance*annual/1200;interest+=charge;balance+=charge;double payment=fixed>0?fixed:Math.max(balance*pct,floor);if(payment<=charge+.01)return new CardPlan(month,interest,false);balance-=Math.min(balance,payment);month++;}return new CardPlan(month,interest,balance<=.5);}
    private static final class TwinInput {double income,expense,emi,invest,assets,liabilities,ret,growth,inflation,shockPct;int years,shockMonths,shockStart;TwinInput(Map<String,Double>x){income=required(x,"income");expense=required(x,"expense");emi=v(x,"emi");invest=v(x,"invest");assets=v(x,"assets");liabilities=v(x,"liabilities");ret=v(x,"return");growth=v(x,"growth");inflation=v(x,"inflation");years=(int)range(x,"years",1,40);shockPct=range(x,"shockPct",0,100);shockMonths=(int)range(x,"shockMonths",1,years*12);shockStart=(int)range(x,"shockStart",0,years*12-1);}}
    private static final class TwinPath {double net,low;TwinPath(double n,double l){net=n;low=l;}}
    private static TwinPath twin(TwinInput x,boolean stressed){double assets=x.assets,liabilities=x.liabilities,low=Double.POSITIVE_INFINITY;for(int month=0;month<x.years*12;month++){int year=month/12;double income=x.income*Math.pow(1+x.growth/100,year),expense=x.expense*Math.pow(1+x.inflation/100,year),received=income;if(stressed&&month>=x.shockStart&&month<x.shockStart+x.shockMonths)received*=1-x.shockPct/100;double cash=received-expense-x.emi-x.invest;low=Math.min(low,cash);assets*=1+x.ret/1200;assets=Math.max(0,assets+x.invest+cash);liabilities=Math.max(0,liabilities-x.emi*.55);}return new TwinPath(assets-liabilities,low);}

    private static String wordsIndian(long n){if(n==0)return "Zero";if(n<0)return "Minus "+wordsIndian(-n);StringBuilder out=new StringBuilder();long crore=n/10000000;n%=10000000;long lakh=n/100000;n%=100000;long thousand=n/1000;n%=1000;if(crore>0)out.append(wordsBelowThousand(crore)).append(" Crore ");if(lakh>0)out.append(wordsBelowThousand(lakh)).append(" Lakh ");if(thousand>0)out.append(wordsBelowThousand(thousand)).append(" Thousand ");if(n>0)out.append(wordsBelowThousand(n));return out.toString().trim();}
    private static String wordsBelowThousand(long n){String[] one={"","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"};String[] tens={"","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"};StringBuilder out=new StringBuilder();if(n>=100){out.append(one[(int)(n/100)]).append(" Hundred ");n%=100;}if(n<20)out.append(one[(int)n]);else{out.append(tens[(int)(n/10)]);if(n%10>0)out.append(" ").append(one[(int)(n%10)]);}return out.toString().trim();}

    private static void hideKeyboard(Context context,View view){InputMethodManager manager=(InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);if(manager!=null)manager.hideSoftInputFromWindow(view.getWindowToken(),0);}

    private static LinearLayout specialPage(MainActivity host, ToolCatalog.Tool tool, String badge, String detail) {
        LinearLayout page = new LinearLayout(host);
        LinearLayout intro = UiKit.card(host);
        TextView chip = UiKit.text(host, badge.toUpperCase(Locale.US), 10, UiKit.TEAL, true);
        chip.setLetterSpacing(.06f); intro.addView(chip);
        TextView title = UiKit.text(host, tool.title, 24, UiKit.ink(host), true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);tp.topMargin=UiKit.dp(host,10);title.setLayoutParams(tp);intro.addView(title);
        TextView description = UiKit.text(host, detail, 13, UiKit.muted(host), false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);dp.topMargin=UiKit.dp(host,7);description.setLayoutParams(dp);intro.addView(description);
        page.addView(intro); return page;
    }

    private static View buildChecklist(final MainActivity host, final ToolCatalog.Tool tool) {
        final LinearLayout page=specialPage(host,tool,"● Native readiness tracker","Tick documents as they become ready. Progress is stored privately in Android app storage.");
        LinearLayout card=UiKit.card(host);page.addView(card);
        final LinearLayout tabs=UiKit.row(host), list=new LinearLayout(host);list.setOrientation(LinearLayout.VERTICAL);
        final TextView progress=UiKit.text(host,"",13,UiKit.INDIGO,true);final String[] profile={"salaried"};
        String[] labels={"Salaried","Business","Property"};String[] ids={"salaried","business","property"};
        for(int index=0;index<labels.length;index++){final String id=ids[index];TextView tab=UiKit.button(host,labels[index],false);UiKit.addWeighted(tabs,tab,1f,index==0?0:6);host.bindClick(tab,new View.OnClickListener(){@Override public void onClick(View v){profile[0]=id;renderChecklist(host,id,list,progress);}});}card.addView(tabs);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);pp.topMargin=UiKit.dp(host,14);pp.bottomMargin=UiKit.dp(host,8);progress.setLayoutParams(pp);card.addView(progress);card.addView(list);
        TextView reset=UiKit.button(host,"Reset this checklist",false);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);rp.topMargin=UiKit.dp(host,12);reset.setLayoutParams(rp);card.addView(reset);host.bindClick(reset,new View.OnClickListener(){@Override public void onClick(View v){for(String item:checklist(profile[0]))AppStore.prefs(host).edit().remove("doc_"+profile[0]+"_"+item.hashCode()).apply();renderChecklist(host,profile[0],list,progress);}});
        renderChecklist(host,profile[0],list,progress);return UiKit.page(host,page);
    }

    private static String[] checklist(String profile){
        if("business".equals(profile))return new String[]{"Personal and business KYC","Business registration / constitution proof","Income-tax returns with computation — 3 years","Audited financial statements — 3 years","GST returns and turnover reconciliation","Business and personal bank statements — 12 months","Complete debt and repayment schedule","Office / business-premises proof","Own-contribution banking trail"};
        if("property".equals(profile))return new String[]{"Agreement to sell / allotment letter","Title deed and prior chain documents","Sanctioned building plan","RERA registration where applicable","Required NOCs and approvals","Completion / occupancy certificate","Latest property-tax and utility receipts","Encumbrance / search report","Society papers and share certificate","Seller / builder KYC and verified bank details"};
        return new String[]{"PAN and identity proof","Current-address proof","Recent photographs","Latest 3 salary slips","Salary-account statements — 6 months","Form 16 — latest 2 years","Latest ITR acknowledgement","Employment continuity proof","Statements for running loans and cards","Down-payment / own-contribution banking trail"};
    }

    private static void renderChecklist(final MainActivity host,final String profile,final LinearLayout list,final TextView progress){list.removeAllViews();int done=0;for(String item:checklist(profile))if(AppStore.prefs(host).getBoolean("doc_"+profile+"_"+item.hashCode(),false))done++;progress.setText(done+" of "+checklist(profile).length+" ready · "+Math.round(done*100f/checklist(profile).length)+"%");for(final String item:checklist(profile)){CheckBox box=new CheckBox(host);box.setText(item);box.setTextSize(13);box.setTextColor(UiKit.ink(host));box.setGravity(Gravity.CENTER_VERTICAL);box.setMinHeight(UiKit.dp(host,52));box.setPadding(UiKit.dp(host,6),UiKit.dp(host,5),UiKit.dp(host,6),UiKit.dp(host,5));box.setChecked(AppStore.prefs(host).getBoolean("doc_"+profile+"_"+item.hashCode(),false));box.setOnCheckedChangeListener((button,checked)->{AppStore.prefs(host).edit().putBoolean("doc_"+profile+"_"+item.hashCode(),checked).apply();host.haptic(false);renderChecklist(host,profile,list,progress);});list.addView(box);}}

    private static void saveLoanResult(MainActivity host,CalcResult result){try{JSONArray all=AppStore.array(host,"saved_loans");JSONObject item=new JSONObject();item.put("name","Loan profile "+new SimpleDateFormat("dd MMM, HH:mm",Locale.getDefault()).format(System.currentTimeMillis()));item.put("primary",result.primaryValue);item.put("summary",result.summary("Loan Repayment Studio"));item.put("created",System.currentTimeMillis());JSONArray next=new JSONArray();next.put(item);for(int i=0;i<Math.min(all.length(),49);i++)next.put(all.get(i));AppStore.putArray(host,"saved_loans",next);host.toast("Loan profile saved privately");}catch(JSONException error){host.toast("Could not save this profile");}}

    private static View buildSaved(final MainActivity host,ToolCatalog.Tool tool){LinearLayout page=specialPage(host,tool,"★ Local Android storage","Saved calculations remain inside this app unless you explicitly share or export them.");final LinearLayout list=new LinearLayout(host);list.setOrientation(LinearLayout.VERTICAL);page.addView(list);renderSaved(host,list);return UiKit.page(host,page);}
    private static void renderSaved(final MainActivity host,final LinearLayout list){list.removeAllViews();final JSONArray all=AppStore.array(host,"saved_loans");if(all.length()==0){LinearLayout empty=UiKit.card(host);empty.addView(UiKit.text(host,"No saved loan profiles yet. Run the Loan Repayment Studio and tap “Save loan profile”.",13,UiKit.muted(host),false));list.addView(empty);return;}for(int i=0;i<all.length();i++){final int index=i;JSONObject item=all.optJSONObject(i);if(item==null)continue;LinearLayout card=UiKit.card(host);card.addView(UiKit.text(host,item.optString("name","Saved loan"),15,UiKit.ink(host),true));TextView value=UiKit.text(host,item.optString("primary",""),20,UiKit.INDIGO,true);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);vp.topMargin=UiKit.dp(host,6);value.setLayoutParams(vp);card.addView(value);LinearLayout actions=UiKit.row(host);TextView share=UiKit.button(host,"Share",false),delete=UiKit.button(host,"Delete",false);UiKit.addWeighted(actions,share,1,0);UiKit.addWeighted(actions,delete,1,8);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);ap.topMargin=UiKit.dp(host,12);actions.setLayoutParams(ap);card.addView(actions);final String summary=item.optString("summary","");host.bindClick(share,v->host.shareText("FinDecide saved loan",summary));host.bindClick(delete,v->{JSONArray next=new JSONArray();for(int j=0;j<all.length();j++)if(j!=index)next.put(all.opt(j));AppStore.putArray(host,"saved_loans",next);renderSaved(host,list);});list.addView(card);}}

    private static View buildVault(final MainActivity host,ToolCatalog.Tool tool){LinearLayout page=specialPage(host,tool,"⬡ Explicit export only","Create one portable JSON backup of app data, or restore a backup you selected yourself.");LinearLayout card=UiKit.card(host);JSONArray saved=AppStore.array(host,"saved_loans"),journal=AppStore.array(host,"journal"),calendar=AppStore.array(host,"calendar");card.addView(UiKit.text(host,"Private records on this device",18,UiKit.ink(host),true));card.addView(UiKit.spacer(host,10));card.addView(UiKit.text(host,saved.length()+" loan profiles  ·  "+journal.length()+" decisions  ·  "+calendar.length()+" reminders",13,UiKit.muted(host),false));TextView export=UiKit.button(host,"Export private backup",true),restore=UiKit.button(host,"Restore selected backup",false);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);bp.topMargin=UiKit.dp(host,14);export.setLayoutParams(bp);card.addView(export);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);rp.topMargin=UiKit.dp(host,9);restore.setLayoutParams(rp);card.addView(restore);host.bindClick(export,v->host.requestVaultExport());host.bindClick(restore,v->host.requestVaultImport());page.addView(card);return UiKit.page(host,page);}

    private static View buildCashflow(final MainActivity host,ToolCatalog.Tool tool){LinearLayout page=specialPage(host,tool,"▣ On-device CSV scanner","Choose a bank CSV. The native parser reads it locally; the statement is never uploaded.");LinearLayout card=UiKit.card(host);card.addView(UiKit.text(host,"Accepted columns",16,UiKit.ink(host),true));TextView help=UiKit.text(host,"Date plus Debit/Credit, or Amount with a debit/credit type column. Common narration and description headings are recognized.",12,UiKit.muted(host),false);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);hp.topMargin=UiKit.dp(host,7);help.setLayoutParams(hp);card.addView(help);TextView choose=UiKit.button(host,"Choose statement CSV",true);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);cp.topMargin=UiKit.dp(host,14);choose.setLayoutParams(cp);card.addView(choose);page.addView(card);final LinearLayout result=new LinearLayout(host);result.setOrientation(LinearLayout.VERTICAL);page.addView(result);host.bindClick(choose,v->host.requestCsv(result));return UiKit.page(host,page);}

    static void renderImportedResult(MainActivity host,LinearLayout target,ToolCatalog.Tool tool,CalcResult result){target.removeAllViews();target.addView(resultCard(host,tool,result));host.haptic(true);}

    static CalcResult analyzeCsv(InputStream stream) throws IOException {
        BufferedReader reader=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8));String headerLine=reader.readLine();if(headerLine==null)throw new IllegalArgumentException("The selected CSV is empty.");List<String> headers=parseCsvLine(headerLine);int debit=findHeader(headers,"debit","withdrawal","dr amount"),credit=findHeader(headers,"credit","deposit","cr amount"),amount=findHeader(headers,"amount","transaction amount"),type=findHeader(headers,"type","dr cr","cr dr"),description=findHeader(headers,"narration","description","particular","remarks");if(debit<0&&credit<0&&amount<0)throw new IllegalArgumentException("No debit, credit or amount column was found.");double inflow=0,outflow=0,emiTotal=0,cash=0;int count=0;Map<String,Double> categories=new HashMap<>();String line;while((line=reader.readLine())!=null&&count<100000){List<String> row=parseCsvLine(line);double in=0,out=0;if(debit>=0||credit>=0){in=Math.abs(csvNumber(cell(row,credit)));out=Math.abs(csvNumber(cell(row,debit)));}else{double value=csvNumber(cell(row,amount));String t=cell(row,type).toLowerCase(Locale.US);if(t.contains("dr")||t.contains("debit")||value<0)out=Math.abs(value);else in=Math.abs(value);}if(in==0&&out==0)continue;count++;inflow+=in;outflow+=out;String desc=cell(row,description).toLowerCase(Locale.US),category="Other / transfer";if(desc.matches(".*(emi|loan|nach|ecs|mortgage).*") )category="Loan / EMI";else if(desc.matches(".*(atm|cash withdrawal).*") )category="Cash withdrawal";else if(desc.matches(".*(swiggy|zomato|restaurant|grocery|blinkit|zepto).*") )category="Food & grocery";else if(desc.matches(".*(uber|ola|petrol|diesel|fuel|metro|irctc|airline).*") )category="Transport & travel";else if(desc.matches(".*(amazon|flipkart|myntra|shopping).*") )category="Shopping";else if(desc.matches(".*(electric|water bill|broadband|recharge|gas bill).*") )category="Utilities";if(out>0){categories.put(category,categories.containsKey(category)?categories.get(category)+out:out);if("Loan / EMI".equals(category))emiTotal+=out;if("Cash withdrawal".equals(category))cash+=out;}}
        if(count==0)throw new IllegalArgumentException("No non-zero transactions were detected.");double net=inflow-outflow,rate=inflow>0?net/inflow*100:0;String verdict=net>=0?"The statement shows a surplus. Confirm that one-time credits are not being treated as recurring income.":"Outflows exceeded inflows. Review the largest categories and identify whether the shortfall is recurring.";return r("Detected net cashflow",signedMoney(net),verdict,net<0,m("Total inflow",money(inflow)),m("Total outflow",money(outflow)),m("Savings rate",pct(rate)),m("Loan / EMI debits",money(emiTotal)),m("Cash withdrawals",money(cash)),m("Transactions read",String.valueOf(count)));
    }
    private static List<String> parseCsvLine(String line){List<String> out=new ArrayList<>();StringBuilder value=new StringBuilder();boolean quoted=false;for(int i=0;i<line.length();i++){char c=line.charAt(i);if(c=='"'){if(quoted&&i+1<line.length()&&line.charAt(i+1)=='"'){value.append('"');i++;}else quoted=!quoted;}else if(c==','&&!quoted){out.add(value.toString().trim());value.setLength(0);}else value.append(c);}out.add(value.toString().trim());return out;}
    private static int findHeader(List<String> headers,String...names){for(int i=0;i<headers.size();i++){String h=headers.get(i).toLowerCase(Locale.US).replaceAll("[^a-z0-9]+"," ").trim();for(String name:names)if(h.equals(name)||h.contains(name))return i;}return -1;}
    private static String cell(List<String> row,int index){return index>=0&&index<row.size()?row.get(index):"";}
    private static double csvNumber(String value){try{boolean negative=value.trim().startsWith("(")||value.trim().startsWith("-");double result=Double.parseDouble(value.replaceAll("[^0-9.]", ""));return negative?-result:result;}catch(Exception e){return 0;}}

    private static View buildJournal(final MainActivity host,ToolCatalog.Tool tool){final LinearLayout page=specialPage(host,tool,"✎ Private decision memory","Record what you chose and why. A decision journal helps you audit reasoning instead of judging only the outcome.");LinearLayout form=UiKit.card(host);form.addView(UiKit.label(host,"Decision title"));final EditText title=UiKit.input(host,"e.g. Choose fixed-rate home loan","",false);form.addView(title);form.addView(UiKit.label(host,"Decision made"));final EditText choice=UiKit.input(host,"What did you choose?","",false);form.addView(choice);form.addView(UiKit.label(host,"Reasoning and assumptions"));final EditText reason=UiKit.input(host,"Key facts, risks and trade-offs","",false);reason.setSingleLine(false);reason.setMinLines(3);reason.setGravity(Gravity.TOP);reason.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|InputType.TYPE_TEXT_FLAG_MULTI_LINE);reason.setPadding(UiKit.dp(host,14),UiKit.dp(host,13),UiKit.dp(host,14),UiKit.dp(host,13));form.addView(reason);TextView save=UiKit.button(host,"Save decision locally",true);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);sp.topMargin=UiKit.dp(host,14);save.setLayoutParams(sp);form.addView(save);page.addView(form);final LinearLayout list=new LinearLayout(host);list.setOrientation(LinearLayout.VERTICAL);page.addView(list);host.bindClick(save,v->{if(title.getText().toString().trim().isEmpty()||choice.getText().toString().trim().isEmpty()){host.toast("Add a title and the decision made");return;}try{JSONArray all=AppStore.array(host,"journal");JSONObject item=new JSONObject();item.put("title",title.getText().toString().trim());item.put("choice",choice.getText().toString().trim());item.put("reason",reason.getText().toString().trim());item.put("created",System.currentTimeMillis());JSONArray next=new JSONArray();next.put(item);for(int i=0;i<Math.min(all.length(),99);i++)next.put(all.get(i));AppStore.putArray(host,"journal",next);title.setText("");choice.setText("");reason.setText("");renderJournal(host,list);host.haptic(true);}catch(JSONException e){host.toast("Could not save this decision");}});renderJournal(host,list);return UiKit.page(host,page);}
    private static void renderJournal(final MainActivity host,final LinearLayout list){list.removeAllViews();final JSONArray all=AppStore.array(host,"journal");if(all.length()==0){LinearLayout empty=UiKit.card(host);empty.addView(UiKit.text(host,"No decisions recorded yet.",13,UiKit.muted(host),false));list.addView(empty);return;}for(int i=0;i<all.length();i++){final int index=i;JSONObject item=all.optJSONObject(i);if(item==null)continue;LinearLayout card=UiKit.card(host);card.addView(UiKit.text(host,item.optString("title"),16,UiKit.ink(host),true));TextView copy=UiKit.text(host,"Choice: "+item.optString("choice")+(item.optString("reason").isEmpty()?"":"\n\n"+item.optString("reason")),12,UiKit.muted(host),false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);cp.topMargin=UiKit.dp(host,7);copy.setLayoutParams(cp);card.addView(copy);LinearLayout actions=UiKit.row(host);TextView share=UiKit.button(host,"Share",false),delete=UiKit.button(host,"Delete",false);UiKit.addWeighted(actions,share,1,0);UiKit.addWeighted(actions,delete,1,8);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);ap.topMargin=UiKit.dp(host,12);actions.setLayoutParams(ap);card.addView(actions);final String text="FINDECIDE NATIVE — DECISION RECORD\n"+item.optString("title")+"\nChoice: "+item.optString("choice")+"\nReasoning: "+item.optString("reason");host.bindClick(share,v->host.shareText("FinDecide decision",text));host.bindClick(delete,v->{JSONArray next=new JSONArray();for(int j=0;j<all.length();j++)if(j!=index)next.put(all.opt(j));AppStore.putArray(host,"journal",next);renderJournal(host,list);});list.addView(card);}}

    private static View buildMatrix(final MainActivity host,ToolCatalog.Tool tool){LinearLayout page=specialPage(host,tool,"⚖ Evidence-weighted choice","Compare three options across five weighted criteria. Scores run from 1 (poor) to 10 (excellent).");LinearLayout form=UiKit.card(host);final EditText[] names={UiKit.input(host,"Option A","Option A",false),UiKit.input(host,"Option B","Option B",false),UiKit.input(host,"Option C","Option C",false)};form.addView(UiKit.label(host,"Option names"));LinearLayout nameRow=UiKit.row(host);for(int i=0;i<3;i++)UiKit.addWeighted(nameRow,names[i],1,i==0?0:6);form.addView(nameRow);final String[] criteria={"Affordability","Risk control","Flexibility","Long-term upside","Simplicity"};final int[] defaultWeights={30,25,20,15,10};final EditText[] weights=new EditText[5];final EditText[][] scores=new EditText[5][3];for(int row=0;row<5;row++){form.addView(UiKit.label(host,criteria[row]+" · weight and A/B/C scores"));LinearLayout inputs=UiKit.row(host);weights[row]=UiKit.input(host,"Weight",String.valueOf(defaultWeights[row]),true);UiKit.addWeighted(inputs,weights[row],1,0);for(int col=0;col<3;col++){scores[row][col]=UiKit.input(host,String.valueOf((char)('A'+col)),"5",true);UiKit.addWeighted(inputs,scores[row][col],1,6);}form.addView(inputs);}TextView run=UiKit.button(host,"Rank the options",true);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);rp.topMargin=UiKit.dp(host,15);run.setLayoutParams(rp);form.addView(run);page.addView(form);final LinearLayout result=new LinearLayout(host);result.setOrientation(LinearLayout.VERTICAL);page.addView(result);host.bindClick(run,v->{double weightTotal=0;double[] totals={0,0,0};for(int row=0;row<5;row++){double weight=number(weights[row].getText().toString());weightTotal+=weight;for(int col=0;col<3;col++){double score=number(scores[row][col].getText().toString());if(score<1||score>10){host.toast("Every score must be from 1 to 10");return;}totals[col]+=weight*score;}}if(Math.abs(weightTotal-100)>.01){host.toast("Weights must total exactly 100");return;}int winner=totals[1]>totals[0]?1:0;if(totals[2]>totals[winner])winner=2;for(int i=0;i<3;i++)totals[i]/=100;CalcResult output=r("Evidence-weighted leader",names[winner].getText().toString()+" · "+two(totals[winner])+" / 10","Review the winner's weakest criterion and validate every score with real evidence before committing.",false,m(names[0].getText().toString(),two(totals[0])+" / 10"),m(names[1].getText().toString(),two(totals[1])+" / 10"),m(names[2].getText().toString(),two(totals[2])+" / 10"));renderImportedResult(host,result,ToolCatalog.find("decisionmatrix"),output);});return UiKit.page(host,page);}

    private static View buildScamShield(final MainActivity host,ToolCatalog.Tool tool){LinearLayout page=specialPage(host,tool,"◈ Native safety check","Tick every signal that applies. No message, number or screenshot leaves the phone.");LinearLayout form=UiKit.card(host);final String[] signals={"Guaranteed or unusually high returns","Immediate action or account-closure threat","Asked for OTP, PIN, CVV, password or screen sharing","Payment to personal UPI, wallet or crypto address","Moved to WhatsApp/Telegram without official documents","Recovery of lost money after an upfront fee","Discourages checking with family, bank or adviser","Misspelled domain or unverifiable app / website"};final int[] risks={18,14,20,15,10,12,8,8};final List<CheckBox> boxes=new ArrayList<>();for(String signal:signals){CheckBox box=new CheckBox(host);box.setText(signal);box.setTextSize(13);box.setTextColor(UiKit.ink(host));box.setMinHeight(UiKit.dp(host,54));box.setGravity(Gravity.CENTER_VERTICAL);boxes.add(box);form.addView(box);}TextView assess=UiKit.button(host,"Assess the request",true);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);ap.topMargin=UiKit.dp(host,14);assess.setLayoutParams(ap);form.addView(assess);page.addView(form);final LinearLayout result=new LinearLayout(host);result.setOrientation(LinearLayout.VERTICAL);page.addView(result);host.bindClick(assess,v->{int score=0;for(int i=0;i<boxes.size();i++)if(boxes.get(i).isChecked())score+=risks[i];score=Math.min(100,score);String label,verdict;if(score>=50){label="Critical danger";verdict="Stop contact. Do not pay, install an app or share credentials. Contact the institution through a separately verified official channel and preserve evidence.";}else if(score>=30){label="High risk";verdict="Multiple strong warning signals are present. Pause the transaction and independently verify the entity and beneficiary.";}else if(score>=15){label="Caution required";verdict="Do not rely on urgency, screenshots or testimonials. Verify licence, identity and payment destination before acting.";}else{label="No major signal selected";verdict="This does not prove legitimacy. Continue to use official apps, verified beneficiary names and independent checks.";}CalcResult output=r("Risk signal score",score+" / 100 · "+label,verdict,score>=30,m("Credentials rule","Never share OTP / PIN / CVV"),m("Verification rule","Use a separate official channel"),m("If money was sent","Contact bank/payment provider now"));renderImportedResult(host,result,ToolCatalog.find("scamshield"),output);if(score>=50)host.haptic(true);});return UiKit.page(host,page);}

    private static View buildCalendar(final MainActivity host,ToolCatalog.Tool tool){final LinearLayout page=specialPage(host,tool,"◷ Android notification scheduler","Choose a date and time using native Android pickers. Reminders work after the app is closed.");LinearLayout form=UiKit.card(host);form.addView(UiKit.label(host,"Reminder title"));final EditText title=UiKit.input(host,"e.g. Review insurance renewal","",false);form.addView(title);form.addView(UiKit.label(host,"Private note"));final EditText note=UiKit.input(host,"Optional context","",false);form.addView(note);final Calendar selected=Calendar.getInstance();selected.add(Calendar.DAY_OF_MONTH,1);selected.set(Calendar.HOUR_OF_DAY,10);selected.set(Calendar.MINUTE,0);selected.set(Calendar.SECOND,0);final TextView when=UiKit.button(host,formatDate(selected.getTimeInMillis()),false);LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);wp.topMargin=UiKit.dp(host,14);when.setLayoutParams(wp);form.addView(when);host.bindClick(when,v->new DatePickerDialog(host,(picker,year,month,day)->{selected.set(year,month,day);new TimePickerDialog(host,(time,hour,minute)->{selected.set(Calendar.HOUR_OF_DAY,hour);selected.set(Calendar.MINUTE,minute);when.setText(formatDate(selected.getTimeInMillis()));},selected.get(Calendar.HOUR_OF_DAY),selected.get(Calendar.MINUTE),false).show();},selected.get(Calendar.YEAR),selected.get(Calendar.MONTH),selected.get(Calendar.DAY_OF_MONTH)).show());TextView schedule=UiKit.button(host,"Schedule native reminder",true);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);sp.topMargin=UiKit.dp(host,9);schedule.setLayoutParams(sp);form.addView(schedule);page.addView(form);final LinearLayout list=new LinearLayout(host);list.setOrientation(LinearLayout.VERTICAL);page.addView(list);host.bindClick(schedule,v->{String value=title.getText().toString().trim();if(value.isEmpty()){host.toast("Add a reminder title");return;}if(selected.getTimeInMillis()<System.currentTimeMillis()+60000){host.toast("Choose a future time");return;}try{int id=(int)(System.currentTimeMillis()%2000000000L);JSONObject item=new JSONObject();item.put("id",id);item.put("title",value);item.put("note",note.getText().toString().trim());item.put("when",selected.getTimeInMillis());JSONArray all=AppStore.array(host,"calendar");all.put(item);AppStore.putArray(host,"calendar",all);host.scheduleReminder(id,value,note.getText().toString().trim(),selected.getTimeInMillis());title.setText("");note.setText("");renderCalendar(host,list);}catch(JSONException e){host.toast("Could not save reminder");}});renderCalendar(host,list);return UiKit.page(host,page);}
    private static String formatDate(long when){return new SimpleDateFormat("EEE, dd MMM yyyy · hh:mm a",Locale.getDefault()).format(when);}
    private static void renderCalendar(final MainActivity host,final LinearLayout list){list.removeAllViews();final JSONArray all=AppStore.array(host,"calendar");if(all.length()==0){LinearLayout empty=UiKit.card(host);empty.addView(UiKit.text(host,"No financial dates scheduled yet.",13,UiKit.muted(host),false));list.addView(empty);return;}List<JSONObject> items=new ArrayList<>();for(int i=0;i<all.length();i++)if(all.optJSONObject(i)!=null)items.add(all.optJSONObject(i));Collections.sort(items,Comparator.comparingLong(o->o.optLong("when")));for(final JSONObject item:items){LinearLayout card=UiKit.card(host);card.addView(UiKit.text(host,item.optString("title"),15,UiKit.ink(host),true));TextView date=UiKit.text(host,formatDate(item.optLong("when"))+(item.optString("note").isEmpty()?"":"\n"+item.optString("note")),12,UiKit.muted(host),false);LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);dp.topMargin=UiKit.dp(host,6);date.setLayoutParams(dp);card.addView(date);TextView delete=UiKit.button(host,"Delete reminder",false);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);bp.topMargin=UiKit.dp(host,10);delete.setLayoutParams(bp);card.addView(delete);host.bindClick(delete,v->{JSONArray next=new JSONArray();for(int i=0;i<all.length();i++){JSONObject current=all.optJSONObject(i);if(current!=null&&current.optInt("id")!=item.optInt("id"))next.put(current);}AppStore.putArray(host,"calendar",next);host.cancelReminder(item.optInt("id"));renderCalendar(host,list);});list.addView(card);}}
}
