package com.findecide.toolkit;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "financial_reminders";

    @Override public void onReceive(Context context, Intent intent) {
        int id=intent.getIntExtra("notification_id",1001);String title=intent.getStringExtra("title"),text=intent.getStringExtra("text");
        if(title==null||title.trim().isEmpty())title="FinDecide reminder";
        if(text==null||text.trim().isEmpty())text="Open your private financial calendar to review.";
        NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(manager==null)return;
        if(Build.VERSION.SDK_INT>=26){NotificationChannel channel=new NotificationChannel(CHANNEL_ID,"Financial reminders",NotificationManager.IMPORTANCE_HIGH);channel.setDescription("Private reminders scheduled in FinDecide Native");channel.enableVibration(true);manager.createNotificationChannel(channel);}
        Intent open=new Intent(context,MainActivity.class);open.setAction(Intent.ACTION_VIEW);open.setData(Uri.parse("findecide://tool/calendar"));open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);int flags=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;PendingIntent content=PendingIntent.getActivity(context,id,open,flags);
        Notification.Builder builder=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,CHANNEL_ID):new Notification.Builder(context);builder.setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setContentIntent(content).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).setVisibility(Notification.VISIBILITY_PRIVATE);if(Build.VERSION.SDK_INT<26)builder.setPriority(Notification.PRIORITY_HIGH);if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;manager.notify(id,builder.build());
    }
}
