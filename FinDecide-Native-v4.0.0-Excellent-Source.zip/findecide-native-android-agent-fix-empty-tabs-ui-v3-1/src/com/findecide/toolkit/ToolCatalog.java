package com.findecide.toolkit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

final class ToolCatalog {
    static final String BORROW = "borrow";
    static final String GROW = "grow";
    static final String PLAN = "plan";
    static final String MORE = "more";

    static final class Tool {
        final String id;
        final String title;
        final String description;
        final String icon;
        final String category;
        final String kind;

        Tool(String id, String title, String description, String icon, String category, String kind) {
            this.id = id;
            this.title = title;
            this.description = description;
            this.icon = icon;
            this.category = category;
            this.kind = kind;
        }

        boolean matches(String query) {
            String haystack = (title + " " + description + " " + kind + " " + category).toLowerCase(Locale.US);
            return haystack.contains(query.toLowerCase(Locale.US));
        }
    }

    static final List<Tool> ALL = Collections.unmodifiableList(Arrays.asList(
        new Tool("emi", "Loan Repayment Studio", "EMI, interest and full repayment cost", "₹", BORROW, "Calculate"),
        new Tool("eligibility", "Eligibility Studio", "Income-based loan capacity and FOIR", "⌁", BORROW, "Calculate"),
        new Tool("health", "Loan Readiness Lab", "FOIR, LTV, credit and buffer score", "✓", BORROW, "Decide"),
        new Tool("odloan", "OD / Max-Saving Loan", "Value of parking surplus against a loan", "↔", BORROW, "Decide"),
        new Tool("aprplus", "True Loan APR", "Expose fees, insurance and net cost", "%", BORROW, "Decide"),
        new Tool("reset", "Rate Reset Shock", "New EMI and tenure after a rate change", "↯", BORROW, "Decide"),
        new Tool("debtplan", "Debt Freedom Strategy", "Avalanche versus snowball payoff", "⇣", BORROW, "Decide"),
        new Tool("rentbuy", "Rent vs Buy Lab", "Compare ending wealth, not only EMI", "⌂", BORROW, "Decide"),
        new Tool("prepayinvest", "Prepay vs Invest", "Certain loan saving versus market return", "⚖", BORROW, "Decide"),
        new Tool("moratorium", "Moratorium Trap", "Reveal the cost of an EMI holiday", "Ⅱ", BORROW, "Decide"),
        new Tool("creditescape", "Credit Card Escape", "Minimum-due trap versus fixed payoff", "⌁", BORROW, "Decide"),
        new Tool("compare", "Compare Loan Offers", "Rank three offers by complete cost", "≡", BORROW, "Decide"),
        new Tool("flat", "Flat ⇄ Reducing Rate", "Decode the true rate behind a quote", "⇄", BORROW, "Calculate"),
        new Tool("bt", "Balance Transfer", "Test if switching lender really pays", "↪", BORROW, "Decide"),
        new Tool("propertycost", "Property Cash Planner", "Down payment, charges and reserves", "⌂", BORROW, "Calculate"),
        new Tool("docs", "Home Loan File Checklist", "Private document-readiness tracker", "☑", BORROW, "Organize"),
        new Tool("saved", "Saved Loan Profiles", "Keep important loan scenarios locally", "★", BORROW, "Organize"),

        new Tool("wealth", "Investment Builder", "SIP, step-up and lump-sum projection", "↗", GROW, "Calculate"),
        new Tool("deposits", "Deposit Builder", "FD and recurring-deposit maturity", "▤", GROW, "Calculate"),
        new Tool("swp", "Withdrawal Runway", "How long regular withdrawals may last", "↙", GROW, "Calculate"),
        new Tool("realreturn", "Real Return Lens", "Return after both tax and inflation", "◎", GROW, "Decide"),
        new Tool("rebalance", "Portfolio Rebalancing", "Turn allocation drift into actions", "◫", GROW, "Decide"),

        new Tool("tax", "Income Tax Comparison", "Indicative old versus new regime", "₹", PLAN, "Calculate"),
        new Tool("hra", "HRA Exemption", "Estimate eligible house-rent exemption", "⌂", PLAN, "Calculate"),
        new Tool("emergency", "Emergency Fund Architect", "Risk-adjusted household reserve", "⊕", PLAN, "Decide"),
        new Tool("retire", "Retirement Corpus", "Inflation-aware corpus and SIP gap", "⌛", PLAN, "Calculate"),
        new Tool("insurance", "Life Cover Gap", "Need-based family protection estimate", "◈", PLAN, "Decide"),
        new Tool("networth", "Net Worth Snapshot", "Track assets and liabilities privately", "◐", PLAN, "Organize"),
        new Tool("moneyhealth", "Money Health Check", "Prioritized whole-picture diagnostic", "◉", PLAN, "Decide"),
        new Tool("twin", "Financial Twin Simulator", "Baseline future versus income shock", "✦", PLAN, "Decide"),
        new Tool("bonusplan", "Bonus & Windfall Allocator", "Priority waterfall for one-time money", "⇣", PLAN, "Decide"),

        new Tool("gst", "GST Split", "Add, remove and split GST", "%", MORE, "Calculate"),
        new Tool("words", "Amount in Words", "Indian rupee wording for documents", "अ", MORE, "Calculate"),
        new Tool("vault", "Private Data Vault", "Device-local backup and restore", "⬡", MORE, "Organize"),
        new Tool("dscr", "DSCR & Business Loan", "Business debt-service capacity", "×", MORE, "Calculate"),
        new Tool("cashflow", "Bank Statement Scan", "On-device CSV cashflow analysis", "▣", MORE, "Private data"),
        new Tool("journal", "Money Decision Journal", "Record reasoning and review dates", "✎", MORE, "Organize"),
        new Tool("decisionmatrix", "Decision Matrix Pro", "Rank choices with weighted evidence", "⚖", MORE, "Decide"),
        new Tool("scamshield", "Scam Shield Check", "Test requests for fraud red flags", "◈", MORE, "Decide"),
        new Tool("calendar", "Financial Calendar", "Native reminders for money deadlines", "◷", MORE, "Organize")
    ));

    static Tool find(String id) {
        for (Tool tool : ALL) if (tool.id.equals(id)) return tool;
        return null;
    }

    static List<Tool> category(String category) {
        List<Tool> result = new ArrayList<>();
        for (Tool tool : ALL) if (tool.category.equals(category)) result.add(tool);
        return result;
    }

    static List<Tool> search(String query) {
        if (query == null || query.trim().isEmpty()) return ALL;
        List<Tool> result = new ArrayList<>();
        for (Tool tool : ALL) if (tool.matches(query.trim())) result.add(tool);
        return result;
    }

    private ToolCatalog() {}
}
