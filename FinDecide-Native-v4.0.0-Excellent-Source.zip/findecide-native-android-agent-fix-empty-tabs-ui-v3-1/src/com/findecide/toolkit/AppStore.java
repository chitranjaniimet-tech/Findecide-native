package com.findecide.toolkit;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

final class AppStore {
    private static final String NAME = "findecide_native_store";

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    static boolean isDark(Context context) { return prefs(context).getBoolean("setting_dark", false); }
    static boolean haptics(Context context) { return prefs(context).getBoolean("setting_haptics", true); }
    static boolean secure(Context context) { return prefs(context).getBoolean("setting_secure", false); }
    static boolean autoLock(Context context) { return prefs(context).getBoolean("setting_auto_lock", false); }

    static void set(Context context, String key, boolean value) { prefs(context).edit().putBoolean(key, value).apply(); }
    static String get(Context context, String key, String fallback) { return prefs(context).getString(key, fallback); }
    static void put(Context context, String key, String value) { prefs(context).edit().putString(key, value).apply(); }

    static JSONArray array(Context context, String key) {
        try { return new JSONArray(get(context, key, "[]")); }
        catch (JSONException error) { return new JSONArray(); }
    }

    static void putArray(Context context, String key, JSONArray value) { put(context, key, value.toString()); }

    static String exportJson(Context context) throws JSONException {
        JSONObject root = new JSONObject();
        root.put("app", "FinDecide Native");
        root.put("schema", 3);
        root.put("exportedAt", System.currentTimeMillis());
        JSONObject data = new JSONObject();
        for (Map.Entry<String, ?> entry : prefs(context).getAll().entrySet()) {
            Object value = entry.getValue();
            if (value instanceof String || value instanceof Boolean || value instanceof Integer || value instanceof Long || value instanceof Float) {
                data.put(entry.getKey(), value);
            }
        }
        root.put("data", data);
        return root.toString(2);
    }

    static int importJson(Context context, String json) throws JSONException {
        JSONObject root = new JSONObject(json);
        if (root.optInt("schema", -1) != 3 || !root.has("data")) throw new JSONException("Not a FinDecide Native backup");
        JSONObject data = root.getJSONObject("data");
        SharedPreferences.Editor editor = prefs(context).edit();
        int count = 0;
        JSONArray names = data.names();
        if (names == null) return 0;
        for (int i = 0; i < names.length(); i++) {
            String key = names.getString(i);
            Object value = data.get(key);
            if (value instanceof Boolean) editor.putBoolean(key, (Boolean) value);
            else if (value instanceof Integer) editor.putInt(key, (Integer) value);
            else if (value instanceof Long) editor.putLong(key, (Long) value);
            else if (value instanceof Double) editor.putFloat(key, ((Double) value).floatValue());
            else editor.putString(key, String.valueOf(value));
            count++;
        }
        editor.apply();
        return count;
    }

    private AppStore() {}
}
