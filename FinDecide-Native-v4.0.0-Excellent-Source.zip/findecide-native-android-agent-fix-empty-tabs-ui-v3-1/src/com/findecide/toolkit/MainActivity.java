package com.findecide.toolkit;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.KeyguardManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_CSV = 201;
    private static final int REQ_VAULT_EXPORT = 202;
    private static final int REQ_VAULT_IMPORT = 203;
    private static final int REQ_PDF = 204;
    private static final int REQ_DEVICE_LOCK = 205;
    private static final int REQ_NOTIFICATIONS = 206;
    private static final String CHANNEL_ID = "financial_reminders";

    private LinearLayout shell, header, bottomNav;
    private FrameLayout content;
    private TextView backButton, headerTitle, headerSubtitle, promo;
    private final Map<String, TextView> navButtons = new HashMap<>();
    private String currentScreen = "home";
    private String currentTool = "";
    private String lastCategory = ToolCatalog.PLAN;
    private long lastBackAt, backgroundAt;
    private boolean requestingLock;
    private LinearLayout pendingCsvResult;
    private String pendingPdfTitle, pendingPdfText;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        applyPrivacyShield();
        configureWindow();
        createNotificationChannel();
        buildShell();
        registerPredictiveBack();
        String launchTool = readLaunchTool(getIntent());
        if (launchTool != null) showTool(launchTool); else showHome();
    }

    private void configureWindow() {
        boolean dark = AppStore.isDark(this);
        getWindow().setStatusBarColor(dark ? Color.rgb(11,18,32) : Color.rgb(245,247,251));
        getWindow().setNavigationBarColor(dark ? Color.rgb(17,27,45) : Color.WHITE);
        if (Build.VERSION.SDK_INT >= 26) getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
    }

    private void buildShell() {
        shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(UiKit.paper(this));
        header = buildHeader();
        shell.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content = new FrameLayout(this);
        content.setBackgroundColor(UiKit.paper(this));
        shell.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        promo = buildPromo();
        shell.addView(promo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UiKit.dp(this, 42)));
        bottomNav = buildBottomNav();
        shell.addView(bottomNav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(shell);
        shell.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int top = insets.getSystemWindowInsetTop(), bottom = insets.getSystemWindowInsetBottom();
                header.setPadding(header.getPaddingLeft(), top + UiKit.dp(MainActivity.this, 8), header.getPaddingRight(), UiKit.dp(MainActivity.this, 8));
                bottomNav.setPadding(bottomNav.getPaddingLeft(), UiKit.dp(MainActivity.this, 5), bottomNav.getPaddingRight(), bottom + UiKit.dp(MainActivity.this, 5));
                return insets;
            }
        });
        shell.requestApplyInsets();
    }

    private LinearLayout buildHeader() {
        LinearLayout bar = UiKit.row(this);
        bar.setPadding(UiKit.dp(this, 16), UiKit.dp(this, 10), UiKit.dp(this, 16), UiKit.dp(this, 10));
        bar.setMinimumHeight(UiKit.dp(this, 72));
        bar.setBackgroundColor(UiKit.surface(this));
        bar.setElevation(UiKit.dp(this, 5));

        backButton = UiKit.text(this, "‹", 34, UiKit.INDIGO, true);
        backButton.setGravity(Gravity.CENTER);
        backButton.setContentDescription("Go back");
        backButton.setBackground(UiKit.background(UiKit.soft(this), 15, this));
        bar.addView(backButton, new LinearLayout.LayoutParams(UiKit.dp(this, 44), UiKit.dp(this, 44)));
        bindClick(backButton, v -> handleBack());

        ImageView icon = new ImageView(this);
        icon.setImageResource(getApplicationInfo().icon);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(UiKit.dp(this, 44), UiKit.dp(this, 44));
        iconParams.leftMargin = UiKit.dp(this, 10);
        bar.addView(icon, iconParams);

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setGravity(Gravity.CENTER_VERTICAL);
        headerTitle = UiKit.text(this, "FinDecide", 19, UiKit.ink(this), true);
        headerTitle.setMaxLines(1);
        headerSubtitle = UiKit.text(this, "DECIDE WITH THE NUMBERS", 9, UiKit.muted(this), true);
        headerSubtitle.setLetterSpacing(.10f);
        copy.addView(headerTitle);
        copy.addView(headerSubtitle);
        LinearLayout.LayoutParams copyParams = new LinearLayout.LayoutParams(0, UiKit.dp(this, 48), 1);
        copyParams.leftMargin = UiKit.dp(this, 10);
        bar.addView(copy, copyParams);

        TextView settings = UiKit.text(this, "⋮", 25, UiKit.ink(this), true);
        settings.setGravity(Gravity.CENTER);
        settings.setContentDescription("App settings");
        settings.setBackground(UiKit.outlined(UiKit.surface(this), UiKit.line(this), 15, this));
        bar.addView(settings, new LinearLayout.LayoutParams(UiKit.dp(this, 44), UiKit.dp(this, 44)));
        bindClick(settings, v -> showSettings());
        return bar;
    }

    private TextView buildPromo() {
        TextView view=UiKit.text(this,"More free money guides  ·  moneyclaritytech.com   ↗",11,Color.WHITE,true);
        view.setGravity(Gravity.CENTER);view.setPadding(UiKit.dp(this,12),0,UiKit.dp(this,12),0);
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(6,42,31),Color.rgb(11,89,65)});bg.setCornerRadius(0);view.setBackground(bg);
        bindClick(view,v->openExternal(Uri.parse("https://www.moneyclaritytech.com/")));return view;
    }

    private LinearLayout buildBottomNav() {
        LinearLayout nav = UiKit.row(this);
        nav.setPadding(UiKit.dp(this, 8), UiKit.dp(this, 6), UiKit.dp(this, 8), UiKit.dp(this, 6));
        nav.setBackgroundColor(UiKit.surface(this));
        nav.setElevation(UiKit.dp(this, 18));
        addNav(nav, "home", "Home", v -> showHome());
        addNav(nav, ToolCatalog.BORROW, "Borrow", v -> showCategory(ToolCatalog.BORROW));
        addNav(nav, ToolCatalog.GROW, "Grow", v -> showCategory(ToolCatalog.GROW));
        addNav(nav, ToolCatalog.PLAN, "Plan", v -> showCategory(ToolCatalog.PLAN));
        addNav(nav, ToolCatalog.MORE, "More", v -> showCategory(ToolCatalog.MORE));
        return nav;
    }

    private void addNav(LinearLayout nav, String id, String label, View.OnClickListener listener) {
        TextView button = UiKit.text(this, label, 11, UiKit.muted(this), true);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(UiKit.dp(this, 50));
        button.setPadding(UiKit.dp(this, 4), UiKit.dp(this, 6), UiKit.dp(this, 4), UiKit.dp(this, 6));
        button.setBackground(UiKit.background(Color.TRANSPARENT, 15, this));
        button.setContentDescription(label + " section");
        navButtons.put(id, button);
        UiKit.addWeighted(nav, button, 1, 2);
        bindClick(button, listener);
    }

    void bindClick(View view, final View.OnClickListener listener) {
        view.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { haptic(false); listener.onClick(v); } });
    }

    public void haptic(boolean strong) {
        if (!AppStore.haptics(this)) return;
        try {
            Vibrator vibrator;
            if (Build.VERSION.SDK_INT >= 31) vibrator=((VibratorManager)getSystemService(Context.VIBRATOR_MANAGER_SERVICE)).getDefaultVibrator();
            else vibrator=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator==null||!vibrator.hasVibrator()) return;
            long duration=strong?42:16;int amplitude=strong?180:90;
            if(Build.VERSION.SDK_INT>=26)vibrator.vibrate(VibrationEffect.createOneShot(duration,amplitude));else vibrator.vibrate(duration);
        } catch(Exception ignored) { }
    }

    private void setScreen(View view,String screen,String title,String subtitle,String selectedNav,boolean showBack){content.removeAllViews();content.addView(view,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));currentScreen=screen;headerTitle.setText(title);headerSubtitle.setText(subtitle.toUpperCase(Locale.US));backButton.setVisibility(showBack?View.VISIBLE:View.INVISIBLE);promo.setVisibility("home".equals(screen)?View.VISIBLE:View.GONE);for(Map.Entry<String,TextView> entry:navButtons.entrySet()){boolean active=entry.getKey().equals(selectedNav);entry.getValue().setTextColor(active?UiKit.INDIGO:UiKit.muted(this));entry.getValue().setBackground(UiKit.background(active?UiKit.soft(this):Color.TRANSPARENT,15,this));}}

    private void showHome() {
        currentTool = "";
        LinearLayout page = new LinearLayout(this);

        LinearLayout hero = UiKit.card(this);
        GradientDrawable heroBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                AppStore.isDark(this)
                        ? new int[]{Color.rgb(16, 31, 54), Color.rgb(17, 73, 72)}
                        : new int[]{Color.rgb(5, 34, 65), Color.rgb(8, 105, 94)});
        heroBg.setCornerRadius(UiKit.dp(this, 28));
        hero.setBackground(heroBg);
        hero.setPadding(UiKit.dp(this, 22), UiKit.dp(this, 24), UiKit.dp(this, 22), UiKit.dp(this, 22));

        TextView kicker = UiKit.text(this, "YOUR PRIVATE MONEY COMPASS", 10, Color.rgb(166, 243, 224), true);
        kicker.setLetterSpacing(.10f);
        hero.addView(kicker);
        TextView title = UiKit.text(this, "Make the better financial move.", 28, Color.WHITE, true);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setLineSpacing(UiKit.dp(this, 3), 1f);
        LinearLayout.LayoutParams titleP = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleP.topMargin = UiKit.dp(this, 10);
        title.setLayoutParams(titleP);
        hero.addView(title);
        TextView subtitle = UiKit.text(this, "Calculate the cost, compare the alternatives, and keep every scenario on your phone.", 14, Color.rgb(219, 238, 244), false);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subP.topMargin = UiKit.dp(this, 9);
        subtitle.setLayoutParams(subP);
        hero.addView(subtitle);

        LinearLayout heroActions = UiKit.row(this);
        TextView health = UiKit.button(this, "Check money health", true);
        health.setBackground(UiKit.background(Color.WHITE, 15, this));
        health.setTextColor(Color.rgb(5, 63, 66));
        TextView recent = UiKit.button(this, "Continue", false);
        recent.setTextColor(Color.WHITE);
        recent.setBackground(UiKit.outlined(Color.TRANSPARENT, Color.argb(110, 255, 255, 255), 15, this));
        UiKit.addWeighted(heroActions, health, 1.35f, 0);
        UiKit.addWeighted(heroActions, recent, .85f, 9);
        LinearLayout.LayoutParams haP = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        haP.topMargin = UiKit.dp(this, 18);
        heroActions.setLayoutParams(haP);
        hero.addView(heroActions);
        bindClick(health, v -> showTool("moneyhealth"));
        bindClick(recent, v -> {
            String id = AppStore.get(this, "recent_tool", "emi");
            showTool(ToolCatalog.find(id) == null ? "emi" : id);
        });
        page.addView(hero);

        TextView section = UiKit.text(this, "START WITH A DECISION", 11, UiKit.muted(this), true);
        section.setLetterSpacing(.08f);
        LinearLayout.LayoutParams sectionP = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sectionP.topMargin = UiKit.dp(this, 8);
        sectionP.bottomMargin = UiKit.dp(this, 8);
        section.setLayoutParams(sectionP);
        page.addView(section);

        page.addView(homeCategoryRow("Borrow smarter", "EMI, eligibility, property and debt decisions", "BORROW", ToolCatalog.BORROW, Color.rgb(45, 100, 230)));
        page.addView(homeCategoryRow("Grow wealth", "Investments, deposits, real return and allocation", "GROW", ToolCatalog.GROW, Color.rgb(6, 139, 112)));
        page.addView(homeCategoryRow("Protect the plan", "Tax, retirement, insurance and emergency reserves", "PLAN", ToolCatalog.PLAN, Color.rgb(198, 112, 19)));
        page.addView(homeCategoryRow("Private utilities", "Statements, reminders, journal and secure backup", "TOOLS", ToolCatalog.MORE, Color.rgb(117, 74, 185)));

        final EditText search = UiKit.input(this, "Search all 41 tools", "", false);
        LinearLayout.LayoutParams searchP = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        searchP.topMargin = UiKit.dp(this, 8);
        searchP.bottomMargin = UiKit.dp(this, 10);
        search.setLayoutParams(searchP);
        page.addView(search);
        final LinearLayout discovery = new LinearLayout(this);
        discovery.setOrientation(LinearLayout.VERTICAL);
        page.addView(discovery);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                discovery.removeAllViews();
                String q = s.toString().trim();
                if (q.isEmpty()) return;
                List<ToolCatalog.Tool> results = ToolCatalog.search(q);
                TextView found = UiKit.text(MainActivity.this, results.size() + " result" + (results.size() == 1 ? "" : "s"), 12, UiKit.muted(MainActivity.this), true);
                LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                fp.bottomMargin = UiKit.dp(MainActivity.this, 7);
                found.setLayoutParams(fp);
                discovery.addView(found);
                for (ToolCatalog.Tool tool : results) discovery.addView(toolCard(tool));
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        setScreen(UiKit.page(this, page), "home", "FinDecide", "Private decision studio", "home", false);
    }

    private void renderHomeDiscovery(LinearLayout host){host.removeAllViews();TextView heading=UiKit.text(this,"What are you deciding?",20,UiKit.ink(this),true);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);hp.bottomMargin=UiKit.dp(this,10);heading.setLayoutParams(hp);host.addView(heading);String[] featured={"twin","moneyhealth","scamshield","decisionmatrix","propertycost","creditescape"};for(String id:featured)host.addView(featureRow(ToolCatalog.find(id)));}
    private void renderSearch(LinearLayout host,String query){host.removeAllViews();List<ToolCatalog.Tool> matches=ToolCatalog.search(query);TextView heading=UiKit.text(this,matches.size()+" matching tool"+(matches.size()==1?"":"s"),14,UiKit.muted(this),true);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);hp.bottomMargin=UiKit.dp(this,10);heading.setLayoutParams(hp);host.addView(heading);for(ToolCatalog.Tool tool:matches)host.addView(featureRow(tool));if(matches.isEmpty())host.addView(UiKit.text(this,"Try EMI, insurance, tax, scam, retirement or cashflow.",13,UiKit.muted(this),false));}
    private View featureRow(final ToolCatalog.Tool tool){LinearLayout row=UiKit.row(this);row.setPadding(UiKit.dp(this,13),UiKit.dp(this,12),UiKit.dp(this,13),UiKit.dp(this,12));row.setBackground(UiKit.outlined(UiKit.surface(this),UiKit.line(this),19,this));row.setElevation(UiKit.dp(this,2));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);rp.bottomMargin=UiKit.dp(this,10);row.setLayoutParams(rp);TextView icon=UiKit.text(this,tool.icon,20,UiKit.INDIGO,true);icon.setGravity(Gravity.CENTER);icon.setBackground(UiKit.background(UiKit.soft(this),14,this));row.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.addView(UiKit.text(this,tool.title,14,UiKit.ink(this),true));TextView desc=UiKit.text(this,tool.description,11,UiKit.muted(this),false);desc.setMaxLines(2);LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);dp.topMargin=UiKit.dp(this,3);desc.setLayoutParams(dp);copy.addView(desc);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);cp.leftMargin=UiKit.dp(this,11);row.addView(copy,cp);TextView arrow=UiKit.text(this,"›",28,UiKit.muted(this),false);row.addView(arrow);bindClick(row,v->showTool(tool.id));return row;}

    private View homeCategoryRow(String title, String description, String badge, final String category, int accent) {
        LinearLayout card = UiKit.row(this);
        card.setPadding(UiKit.dp(this, 16), UiKit.dp(this, 15), UiKit.dp(this, 14), UiKit.dp(this, 15));
        card.setBackground(UiKit.outlined(UiKit.surface(this), UiKit.line(this), 20, this));
        card.setElevation(UiKit.dp(this, AppStore.isDark(this) ? 0 : 2));
        LinearLayout.LayoutParams outer = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        outer.bottomMargin = UiKit.dp(this, 9);
        card.setLayoutParams(outer);

        TextView mark = UiKit.text(this, badge, 10, Color.WHITE, true);
        mark.setGravity(Gravity.CENTER);
        mark.setLetterSpacing(.05f);
        mark.setBackground(UiKit.background(accent, 14, this));
        card.addView(mark, new LinearLayout.LayoutParams(UiKit.dp(this, 58), UiKit.dp(this, 58)));

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = UiKit.text(this, title, 16, UiKit.ink(this), true);
        TextView detail = UiKit.text(this, description, 12, UiKit.muted(this), false);
        LinearLayout.LayoutParams detailP = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        detailP.topMargin = UiKit.dp(this, 4);
        detail.setLayoutParams(detailP);
        copy.addView(name);
        copy.addView(detail);
        LinearLayout.LayoutParams copyP = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        copyP.leftMargin = UiKit.dp(this, 13);
        card.addView(copy, copyP);
        TextView arrow = UiKit.text(this, "›", 28, accent, true);
        arrow.setGravity(Gravity.CENTER);
        card.addView(arrow, new LinearLayout.LayoutParams(UiKit.dp(this, 28), UiKit.dp(this, 48)));
        bindClick(card, v -> showCategory(category));
        return card;
    }

    private void showCategory(final String category) {
        lastCategory = category;
        LinearLayout page = new LinearLayout(this);
        String title = categoryTitle(category);

        LinearLayout intro = UiKit.card(this);
        TextView eyebrow = UiKit.text(this, category.toUpperCase(Locale.US) + " STUDIO", 10, UiKit.INDIGO, true);
        eyebrow.setLetterSpacing(.10f);
        intro.addView(eyebrow);
        TextView heading = UiKit.text(this, title, 25, UiKit.ink(this), true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = UiKit.dp(this, 7);
        heading.setLayoutParams(hp);
        intro.addView(heading);
        TextView description = UiKit.text(this, categoryDescription(category), 13, UiKit.muted(this), false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dp.topMargin = UiKit.dp(this, 6);
        description.setLayoutParams(dp);
        intro.addView(description);
        page.addView(intro);

        List<ToolCatalog.Tool> tools = ToolCatalog.category(category);
        TextView count = UiKit.text(this, tools.size() + " TOOLS · ALL WORK OFFLINE", 10, UiKit.muted(this), true);
        count.setLetterSpacing(.07f);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.bottomMargin = UiKit.dp(this, 8);
        count.setLayoutParams(cp);
        page.addView(count);
        for (ToolCatalog.Tool tool : tools) page.addView(toolCard(tool));
        setScreen(UiKit.page(this, page), "category", title, "Private · works offline", category, false);
    }


    private View toolCard(final ToolCatalog.Tool tool) {
        LinearLayout card = UiKit.row(this);
        card.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 12), UiKit.dp(this, 14));
        card.setMinimumHeight(UiKit.dp(this, 88));
        card.setBackground(UiKit.outlined(UiKit.surface(this), UiKit.line(this), 19, this));
        card.setElevation(UiKit.dp(this, AppStore.isDark(this) ? 0 : 2));
        LinearLayout.LayoutParams outer = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        outer.bottomMargin = UiKit.dp(this, 9);
        card.setLayoutParams(outer);

        TextView icon = UiKit.text(this, tool.icon, 20, UiKit.INDIGO, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(UiKit.background(UiKit.soft(this), 15, this));
        card.addView(icon, new LinearLayout.LayoutParams(UiKit.dp(this, 52), UiKit.dp(this, 52)));

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = UiKit.text(this, tool.title, 15, UiKit.ink(this), true);
        title.setMaxLines(2);
        TextView desc = UiKit.text(this, tool.description, 11, UiKit.muted(this), false);
        desc.setMaxLines(2);
        LinearLayout.LayoutParams descP = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        descP.topMargin = UiKit.dp(this, 4);
        desc.setLayoutParams(descP);
        copy.addView(title);
        copy.addView(desc);
        LinearLayout.LayoutParams copyP = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        copyP.leftMargin = UiKit.dp(this, 12);
        card.addView(copy, copyP);

        LinearLayout tail = new LinearLayout(this);
        tail.setOrientation(LinearLayout.VERTICAL);
        tail.setGravity(Gravity.CENTER);
        TextView kind = UiKit.text(this, tool.kind.toUpperCase(Locale.US), 8, UiKit.TEAL, true);
        kind.setLetterSpacing(.05f);
        TextView arrow = UiKit.text(this, "›", 27, UiKit.INDIGO, true);
        arrow.setGravity(Gravity.CENTER);
        tail.addView(kind);
        tail.addView(arrow);
        card.addView(tail, new LinearLayout.LayoutParams(UiKit.dp(this, 62), ViewGroup.LayoutParams.MATCH_PARENT));
        bindClick(card, v -> showTool(tool.id));
        return card;
    }

    private void showTool(String id) {ToolCatalog.Tool tool=ToolCatalog.find(id);if(tool==null){showHome();return;}lastCategory=tool.category;currentTool=id;AppStore.put(this,"recent_tool",id);View toolView=CalculatorEngine.build(this,tool);setScreen(toolView,"tool",tool.title,"Private · offline",tool.category,true);}

    private void showSettings() {LinearLayout page=new LinearLayout(this);LinearLayout intro=UiKit.card(this);intro.addView(UiKit.text(this,"Privacy & Android controls",24,UiKit.ink(this),true));TextView desc=UiKit.text(this,"These controls operate at the Android window and device level—not inside a browser layer.",13,UiKit.muted(this),false);LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);dp.topMargin=UiKit.dp(this,7);desc.setLayoutParams(dp);intro.addView(desc);page.addView(intro);LinearLayout settings=UiKit.card(this);addSwitch(settings,"Reliable haptic feedback","Uses Android's vibrator service for deliberate taps",AppStore.haptics(this),(button,on)->AppStore.set(this,"setting_haptics",on));addSwitch(settings,"Dark appearance","Native dark surfaces and system bars",AppStore.isDark(this),(button,on)->{AppStore.set(this,"setting_dark",on);recreate();});addSwitch(settings,"Screenshot shield","Blocks screenshots and recent-app previews",AppStore.secure(this),(button,on)->{AppStore.set(this,"setting_secure",on);applyPrivacyShield();});addSwitch(settings,"Auto-lock after background","Requires your device credential after 30 seconds",AppStore.autoLock(this),(button,on)->AppStore.set(this,"setting_auto_lock",on));TextView test=UiKit.button(this,"Test strong vibration",true),lock=UiKit.button(this,"Lock private workspace now",false);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);tp.topMargin=UiKit.dp(this,16);test.setLayoutParams(tp);settings.addView(test);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);lp.topMargin=UiKit.dp(this,9);lock.setLayoutParams(lp);settings.addView(lock);bindClick(test,v->{haptic(true);toast("If you felt a pulse, native haptics are working");});bindClick(lock,v->requestDeviceUnlock());TextView status=UiKit.text(this,"FinDecide 4.0.0\nAndroid "+Build.VERSION.RELEASE+" · API "+Build.VERSION.SDK_INT+"\nVibrator: "+(hasVibrator()?"available":"not reported by device"),12,UiKit.muted(this),false);LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);stp.topMargin=UiKit.dp(this,16);status.setLayoutParams(stp);settings.addView(status);page.addView(settings);setScreen(UiKit.page(this,page),"settings","App controls","Native privacy & interaction","",true);}

    private interface SwitchListener {void changed(Switch button,boolean on);}
    private void addSwitch(LinearLayout parent,String title,String description,boolean checked,final SwitchListener listener){LinearLayout row=UiKit.row(this);row.setPadding(0,UiKit.dp(this,9),0,UiKit.dp(this,9));LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.addView(UiKit.text(this,title,13,UiKit.ink(this),true));copy.addView(UiKit.text(this,description,10,UiKit.muted(this),false));row.addView(copy,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));final Switch toggle=new Switch(this);toggle.setChecked(checked);toggle.setMinWidth(UiKit.dp(this,52));row.addView(toggle);toggle.setOnCheckedChangeListener((button,on)->{haptic(false);listener.changed(toggle,on);});parent.addView(row);}

    private String categoryTitle(String category){if(ToolCatalog.BORROW.equals(category))return "Borrow";if(ToolCatalog.GROW.equals(category))return "Grow";if(ToolCatalog.PLAN.equals(category))return "Plan";return "More";}
    private String categoryDescription(String category){if(ToolCatalog.BORROW.equals(category))return "Loan decisions, property planning and repayment intelligence.";if(ToolCatalog.GROW.equals(category))return "Build, preserve and rebalance long-term wealth.";if(ToolCatalog.PLAN.equals(category))return "Protection, tax, retirement and household resilience.";return "Private data tools, safety systems and utilities.";}

    private void registerPredictiveBack(){if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT,new OnBackInvokedCallback(){@Override public void onBackInvoked(){handleBack();}});}
    @SuppressLint("GestureBackNavigation")
    @Override public void onBackPressed(){if(Build.VERSION.SDK_INT<33)handleBack();}
    private void handleBack(){if("tool".equals(currentScreen)){showCategory(lastCategory);return;}if("category".equals(currentScreen)||"settings".equals(currentScreen)){showHome();return;}long now=System.currentTimeMillis();if(now-lastBackAt<1800){finish();return;}lastBackAt=now;toast("Swipe back again to close FinDecide");}

    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);String id=readLaunchTool(intent);if(id!=null)showTool(id);}
    private String readLaunchTool(Intent intent){if(intent==null)return null;String id=intent.getStringExtra("tool_id");Uri data=intent.getData();if(data!=null&&"findecide".equals(data.getScheme())&&"tool".equals(data.getHost()))id=data.getLastPathSegment();return id!=null&&id.matches("[a-z0-9]{2,40}")&&ToolCatalog.find(id)!=null?id:null;}

    public void shareText(String title,String text){Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");share.putExtra(Intent.EXTRA_SUBJECT,title);share.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(share,"Share from FinDecide"));}
    private void openExternal(Uri uri){try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(ActivityNotFoundException error){toast("No browser is available");}}
    public void toast(String text){Toast.makeText(this,text,Toast.LENGTH_SHORT).show();}

    public void requestCsv(LinearLayout result){pendingCsvResult=result;Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("text/*");try{startActivityForResult(intent,REQ_CSV);}catch(ActivityNotFoundException e){toast("No file picker is available");}}
    public void requestVaultExport(){Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");intent.putExtra(Intent.EXTRA_TITLE,"findecide-native-backup-"+new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())+".json");startActivityForResult(intent,REQ_VAULT_EXPORT);}
    public void requestVaultImport(){Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");startActivityForResult(intent,REQ_VAULT_IMPORT);}
    public void requestPdf(String title,String text){pendingPdfTitle=title;pendingPdfText=text;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/pdf");intent.putExtra(Intent.EXTRA_TITLE,"FinDecide-"+title.replaceAll("[^A-Za-z0-9]+","-")+".pdf");startActivityForResult(intent,REQ_PDF);}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQ_DEVICE_LOCK){requestingLock=false;backgroundAt=0;return;}if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();try{if(requestCode==REQ_CSV){InputStream input=getContentResolver().openInputStream(uri);CalculatorEngine.CalcResult result=CalculatorEngine.analyzeCsv(input);if(input!=null)input.close();if(pendingCsvResult!=null)CalculatorEngine.renderImportedResult(this,pendingCsvResult,ToolCatalog.find("cashflow"),result);}else if(requestCode==REQ_VAULT_EXPORT){writeText(uri,AppStore.exportJson(this));toast("Private backup saved");}else if(requestCode==REQ_VAULT_IMPORT){String json=readText(uri);int count=AppStore.importJson(this,json);toast("Restored "+count+" native data entries");showTool("vault");}else if(requestCode==REQ_PDF){writePdf(uri,pendingPdfTitle,pendingPdfText);toast("PDF saved");}}catch(Exception error){toast(error.getMessage()==null?"Could not process this file":error.getMessage());}}
    private void writeText(Uri uri,String text)throws IOException{OutputStream out=getContentResolver().openOutputStream(uri,"w");if(out==null)throw new IOException("Could not open destination");out.write(text.getBytes(StandardCharsets.UTF_8));out.close();}
    private String readText(Uri uri)throws IOException{InputStream input=getContentResolver().openInputStream(uri);if(input==null)throw new IOException("Could not open selected file");BufferedReader reader=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8));StringBuilder out=new StringBuilder();String line;while((line=reader.readLine())!=null){if(out.length()>5*1024*1024)throw new IOException("Backup is too large");out.append(line).append('\n');}input.close();return out.toString();}
    private void writePdf(Uri uri,String title,String text)throws IOException{PdfDocument document=new PdfDocument();Paint titlePaint=new Paint(Paint.ANTI_ALIAS_FLAG);titlePaint.setColor(Color.rgb(16,42,67));titlePaint.setTextSize(24);titlePaint.setTypeface(Typeface.DEFAULT_BOLD);Paint bodyPaint=new Paint(Paint.ANTI_ALIAS_FLAG);bodyPaint.setColor(Color.rgb(35,50,65));bodyPaint.setTextSize(12);Paint footerPaint=new Paint(Paint.ANTI_ALIAS_FLAG);footerPaint.setColor(Color.rgb(98,125,152));footerPaint.setTextSize(9);String[] raw=(text==null?"":text).split("\n");int pageNumber=1,index=0;while(index<raw.length||pageNumber==1){PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(595,842,pageNumber).create();PdfDocument.Page page=document.startPage(info);float y=58;page.getCanvas().drawText("FinDecide",42,y,titlePaint);y+=28;page.getCanvas().drawText(title==null?"Financial result":title,42,y,bodyPaint);y+=28;while(index<raw.length&&y<780){for(String wrapped:wrap(raw[index],82)){if(y>=780)break;page.getCanvas().drawText(wrapped,42,y,bodyPaint);y+=18;}index++;}page.getCanvas().drawText("Private decision support · moneyclaritytech.com",42,815,footerPaint);document.finishPage(page);pageNumber++;if(raw.length==0)break;}OutputStream output=getContentResolver().openOutputStream(uri,"w");if(output==null)throw new IOException("Could not open PDF destination");document.writeTo(output);output.close();document.close();}
    private List<String> wrap(String line,int max){if(line==null||line.isEmpty())return Arrays.asList("");java.util.ArrayList<String> out=new java.util.ArrayList<>();String remaining=line;while(remaining.length()>max){int cut=remaining.lastIndexOf(' ',max);if(cut<1)cut=max;out.add(remaining.substring(0,cut));remaining=remaining.substring(cut).trim();}out.add(remaining);return out;}

    public void scheduleReminder(int id,String title,String text,long when){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS);Intent reminder=new Intent(this,ReminderReceiver.class);reminder.putExtra("notification_id",id);reminder.putExtra("title",title);reminder.putExtra("text",text);int flags=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;PendingIntent pending=PendingIntent.getBroadcast(this,id,reminder,flags);AlarmManager alarms=(AlarmManager)getSystemService(Context.ALARM_SERVICE);if(alarms!=null){alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pending);toast("Reminder scheduled");}}
    public void cancelReminder(int id){Intent reminder=new Intent(this,ReminderReceiver.class);int flags=PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE;PendingIntent pending=PendingIntent.getBroadcast(this,id,reminder,flags);AlarmManager alarms=(AlarmManager)getSystemService(Context.ALARM_SERVICE);if(pending!=null&&alarms!=null){alarms.cancel(pending);pending.cancel();}}
    private void createNotificationChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager manager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);if(manager!=null){NotificationChannel channel=new NotificationChannel(CHANNEL_ID,"Financial reminders",NotificationManager.IMPORTANCE_HIGH);channel.setDescription("Private reminders scheduled in FinDecide");channel.enableVibration(true);manager.createNotificationChannel(channel);}}}

    private boolean hasVibrator(){try{Vibrator v=Build.VERSION.SDK_INT>=31?((VibratorManager)getSystemService(Context.VIBRATOR_MANAGER_SERVICE)).getDefaultVibrator():(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);return v!=null&&v.hasVibrator();}catch(Exception e){return false;}}
    private void applyPrivacyShield(){if(AppStore.secure(this))getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);}
    private void requestDeviceUnlock(){KeyguardManager manager=(KeyguardManager)getSystemService(Context.KEYGUARD_SERVICE);if(manager==null||!manager.isKeyguardSecure()){toast("Set a phone PIN, pattern or fingerprint first");return;}Intent intent=manager.createConfirmDeviceCredentialIntent("Unlock FinDecide","Confirm your device lock to view private financial data");if(intent!=null){requestingLock=true;startActivityForResult(intent,REQ_DEVICE_LOCK);}}
    @Override protected void onPause(){backgroundAt=System.currentTimeMillis();super.onPause();}
    @Override protected void onResume(){super.onResume();if(!requestingLock&&backgroundAt>0&&System.currentTimeMillis()-backgroundAt>30000&&AppStore.autoLock(this))requestDeviceUnlock();backgroundAt=0;}
}
